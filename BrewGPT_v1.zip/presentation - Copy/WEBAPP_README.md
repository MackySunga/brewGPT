# Coffee Recipe Web App

## Run
```powershell
streamlit run app.py
```

This launches the **Home** page (`app.py`). Use the top menu to switch between:
- `Home`
- `Model Comparison`

## Run (Algorithm Comparison App)
```powershell
streamlit run app_model_comparison.py
```

## Modes
- `Single Recipe`: one weighted taste target -> one recipe.
- `Compare Two Recipes`: independent inputs for Recipe A and Recipe B, with side-by-side comparison.

## What It Does
- Lets users select one or more target taste profiles.
- Lets users set per-taste priority weights.
- Optimizes and returns one complete recommended recipe.
- Shows predicted process outcomes and taste probabilities.
- Supports export to CSV and PDF.

## Inputs
- Taste profile selection (`Tea.floral` ... `Rubber`)
- Per-taste weights (slider per selected taste)
- Search size, penalties, random seed

## Output
- Recommended controllable recipe:
  - `Volume`
  - `Brew Temperature`
  - `Pour Temp`
  - `Dose`
  - `Grind`
- Predicted process outcomes:
  - `90Sec Temp`
  - `Brew Mass`
  - `TDS__1`
  - `Percent Extraction`
- Predicted taste probabilities for selected tastes (+ full profile in expander)

## Exports
- Single mode:
  - `Download CSV`
  - `Download PDF`
- Compare mode:
  - Per-recipe CSV/PDF for Recipe A and Recipe B
  - Combined comparison CSV/PDF

## Notes
- This is a decision-support prototype.
- Validate recommended recipes with real brews and sensory testing.
