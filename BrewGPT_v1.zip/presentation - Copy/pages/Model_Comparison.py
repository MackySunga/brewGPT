from app_model_comparison import main


main()
