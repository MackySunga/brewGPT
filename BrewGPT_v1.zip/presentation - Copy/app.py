﻿import io
import re
import os
import json
import base64
from datetime import datetime

import numpy as np
import pandas as pd
import streamlit as st

from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor, GradientBoostingClassifier
from sklearn.metrics import (
    brier_score_loss,
    f1_score,
    mean_absolute_error,
    mean_squared_error,
    r2_score,
    roc_auc_score,
)
from sklearn.model_selection import train_test_split
from sklearn.neighbors import NearestNeighbors
from sklearn.neural_network import MLPClassifier, MLPRegressor
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

try:
    from reportlab.lib.pagesizes import letter
    from reportlab.pdfgen import canvas

    REPORTLAB_AVAILABLE = True
except Exception:
    REPORTLAB_AVAILABLE = False

try:
    import shap

    SHAP_AVAILABLE = True
except Exception:
    SHAP_AVAILABLE = False

try:
    from xgboost import XGBClassifier, XGBRegressor

    XGBOOST_AVAILABLE = True
except Exception:
    XGBOOST_AVAILABLE = False


DATA_PATH = "cotter_dataset.csv"
LOG_DIR = "logs"
EXPERIMENT_LOG_PATH = os.path.join(LOG_DIR, "experiment_log.csv")
FEEDBACK_LOG_PATH = os.path.join(LOG_DIR, "feedback_log.csv")

TASTE_COLS = [
    "Tea.floral",
    "Fruit",
    "Citrus",
    "Green.veg",
    "Paper.wood",
    "Burnt",
    "Cereal",
    "Nutty",
    "Dark.chocolate",
    "Caramel",
    "Bitter",
    "Astringent",
    "Roasted",
    "Sour",
    "Thick.viscous",
    "Sweet",
    "Rubber",
]

CONTROLLABLE_COLS = [
    "Volume",
    "Brew Temperature",
    "Pour Temp",
    "Dose",
    "Grind",
]

PROCESS_COLS = [
    "90Sec Temp",
    "Brew Mass",
    "TDS__1",
    "Percent Extraction",
]

MODEL_ALGORITHMS = ["RandomForest", "GradientBoosting", "NeuralNetwork"] + (["XGBoost"] if XGBOOST_AVAILABLE else [])

SCENARIO_PRESETS = {
    "Custom": None,
    "Sweet Caramel Comfort": {
        "tastes": ["Sweet", "Caramel", "Nutty"],
        "weights": {"Sweet": 50, "Caramel": 30, "Nutty": 20},
        "n_candidates": 14000,
        "non_selected_penalty": 0.20,
        "distance_weight": 0.08,
    },
    "Bright Citrus Lift": {
        "tastes": ["Citrus", "Fruit", "Tea.floral"],
        "weights": {"Citrus": 45, "Fruit": 35, "Tea.floral": 20},
        "n_candidates": 14000,
        "non_selected_penalty": 0.18,
        "distance_weight": 0.07,
    },
    "Dark Chocolate Roast": {
        "tastes": ["Dark.chocolate", "Roasted", "Bitter"],
        "weights": {"Dark.chocolate": 45, "Roasted": 35, "Bitter": 20},
        "n_candidates": 16000,
        "non_selected_penalty": 0.22,
        "distance_weight": 0.10,
    },
    "Floral Tea Clarity": {
        "tastes": ["Tea.floral", "Citrus", "Sweet"],
        "weights": {"Tea.floral": 45, "Citrus": 35, "Sweet": 20},
        "n_candidates": 14000,
        "non_selected_penalty": 0.16,
        "distance_weight": 0.07,
    },
    "Juicy Fruit Burst": {
        "tastes": ["Fruit", "Citrus", "Sour"],
        "weights": {"Fruit": 45, "Citrus": 35, "Sour": 20},
        "n_candidates": 15000,
        "non_selected_penalty": 0.17,
        "distance_weight": 0.07,
    },
    "Smooth Nutty Balance": {
        "tastes": ["Nutty", "Sweet", "Thick.viscous"],
        "weights": {"Nutty": 45, "Sweet": 30, "Thick.viscous": 25},
        "n_candidates": 14000,
        "non_selected_penalty": 0.18,
        "distance_weight": 0.08,
    },
    "Roasted Bitter Punch": {
        "tastes": ["Roasted", "Bitter", "Burnt"],
        "weights": {"Roasted": 45, "Bitter": 35, "Burnt": 20},
        "n_candidates": 16000,
        "non_selected_penalty": 0.24,
        "distance_weight": 0.10,
    },
    "Bright Clean Cup": {
        "tastes": ["Citrus", "Tea.floral", "Green.veg"],
        "weights": {"Citrus": 45, "Tea.floral": 35, "Green.veg": 20},
        "n_candidates": 15000,
        "non_selected_penalty": 0.16,
        "distance_weight": 0.07,
    },
    "Chocolate Caramel Dessert": {
        "tastes": ["Dark.chocolate", "Caramel", "Sweet"],
        "weights": {"Dark.chocolate": 45, "Caramel": 35, "Sweet": 20},
        "n_candidates": 16000,
        "non_selected_penalty": 0.22,
        "distance_weight": 0.09,
    },
    "Body Heavy Sweet": {
        "tastes": ["Thick.viscous", "Sweet", "Caramel"],
        "weights": {"Thick.viscous": 45, "Sweet": 35, "Caramel": 20},
        "n_candidates": 15000,
        "non_selected_penalty": 0.20,
        "distance_weight": 0.08,
    },
    "Low Bitterness Friendly": {
        "tastes": ["Sweet", "Fruit", "Caramel"],
        "weights": {"Sweet": 45, "Fruit": 35, "Caramel": 20},
        "n_candidates": 14000,
        "non_selected_penalty": 0.15,
        "distance_weight": 0.07,
    },
}

PROPONENTS = [
    {
        "name": "Lorenzo V. Altonaga",
        "image": "Altonaga_Lorenzo_V,_Photo-MSDS2026.jpg",
        "role": "Project lead and modeling direction; aligned taste personalization goals with practical coffee workflow.",
    },
    {
        "name": "Jemiry Royce Sarceda",
        "image": "Sarceda_Jemiry_Royce-MSDS2026.jpg",
        "role": "Data preparation and feature engineering; helped structure inputs for robust recommendation logic.",
    },
    {
        "name": "Bob Mathew Sunga",
        "image": "Sunga_Bob_Mathew-MSDS2026.jpg",
        "role": "Model evaluation and validation support; contributed to significance analysis and quality checks.",
    },
    {
        "name": "Kendrick Francis Torres",
        "image": "Torres__Kendrick_Francis_-_MSDS_2026.jpg",
        "role": "Application integration and user-flow design; helped translate model output into usable dashboard experience.",
    },
]


def inject_dashboard_css():
    st.markdown(
        """
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Baloo+2:wght@700;800&family=Playfair+Display:wght@600;700;800&family=Manrope:wght@400;500;600;700;800&family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@24,400,0,0&display=swap');
            :root {
                --coffee-espresso: #3b2a23;
                --coffee-roast: #5a3d2e;
                --coffee-mocha: #6f4e37;
                --coffee-caramel: #b67a3c;
                --coffee-latte: #a88a73;
                --coffee-cream: #f6eadb;
                --coffee-foam: #fbf6ef;
                --coffee-clay: #e8d8c4;
                --coffee-shadow: rgba(59, 42, 35, 0.14);
                --font-display: "Playfair Display", Georgia, serif;
                --font-body: "Manrope", "Segoe UI", sans-serif;
                --font-fun: "Baloo 2", "Manrope", sans-serif;
            }
            .stApp {
                background: radial-gradient(circle at top right, #fff8ef 0%, #f8ecdd 42%, #f2e1cc 100%);
            }
            html, body, [data-testid="stAppViewContainer"], [data-testid="stMarkdownContainer"], .stTabs [data-baseweb="tab"], .stButton > button {
                font-family: var(--font-body);
            }
            h1, h2, h3, h4, .sticky-main, .narrative-title, .about-title {
                font-family: var(--font-display) !important;
                letter-spacing: 0.01em;
            }
            h1 {
                color: var(--coffee-espresso);
                margin-bottom: 0.15rem;
            }
            h2, h3, h4 {
                color: var(--coffee-roast);
            }
            .material-symbols-rounded {
                font-variation-settings: "FILL" 0, "wght" 350, "GRAD" 0, "opsz" 24;
                vertical-align: middle;
            }
            .block-container {
                padding-top: 1.0rem;
                padding-bottom: 1.8rem;
            }
            .dashboard-card {
                background: linear-gradient(180deg, var(--coffee-foam) 0%, var(--coffee-cream) 100%);
                border: 1px solid #dcc7ad;
                border-radius: 14px;
                padding: 14px 16px;
                box-shadow: 0 2px 8px var(--coffee-shadow);
                margin-bottom: 8px;
                transition: transform 0.18s ease, box-shadow 0.18s ease, border-color 0.18s ease;
            }
            .dashboard-card:hover {
                transform: translateY(-2px);
                box-shadow: 0 8px 20px rgba(59, 42, 35, 0.16);
                border-color: #cba780;
            }
            .kpi-title {
                font-size: 0.82rem;
                font-weight: 600;
                color: var(--coffee-latte);
                margin-bottom: 6px;
                text-transform: uppercase;
                letter-spacing: 0.03em;
            }
            .kpi-value {
                font-size: 1.35rem;
                font-weight: 800;
                color: var(--coffee-espresso);
                line-height: 1.1;
            }
            .kpi-sub {
                margin-top: 6px;
                font-size: 0.8rem;
                color: #6c5344;
            }
            .section-head {
                margin: 2px 0 10px 0;
                font-weight: 700;
                color: var(--coffee-roast);
                font-size: 1.02rem;
                display: flex;
                align-items: center;
                gap: 8px;
            }
            .head-icon {
                color: var(--coffee-caramel);
                font-size: 1.15rem;
            }
            .tab-banner {
                border: 1px solid #ddc5a8;
                border-left: 4px solid var(--coffee-caramel);
                border-radius: 12px;
                padding: 10px 12px;
                margin: 2px 0 12px 0;
                background: linear-gradient(180deg, #fff9f1 0%, #f3e2cd 100%);
                display: flex;
                align-items: center;
                gap: 10px;
                box-shadow: 0 2px 8px rgba(78, 54, 40, 0.08);
                transition: transform 0.16s ease, box-shadow 0.16s ease;
            }
            .tab-banner:hover {
                transform: translateY(-1px);
                box-shadow: 0 6px 16px rgba(78, 54, 40, 0.14);
            }
            .tab-banner-icon {
                color: var(--coffee-roast);
                font-size: 1.45rem;
            }
            .tab-banner-title {
                margin: 0;
                color: var(--coffee-espresso);
                font-weight: 800;
                font-size: 1rem;
                font-family: var(--font-display);
            }
            .tab-banner-sub {
                margin: 0;
                color: #6a5241;
                font-size: 0.83rem;
            }
            .narrative-card {
                background: linear-gradient(180deg, #fff9f1 0%, #f6e8d7 100%);
                border: 1px solid #dec8ad;
                border-left: 4px solid var(--coffee-caramel);
                border-radius: 12px;
                padding: 14px 16px;
                margin: 4px 0 14px 0;
                box-shadow: 0 2px 8px rgba(78, 54, 40, 0.09);
                transition: transform 0.18s ease, box-shadow 0.18s ease;
            }
            .narrative-card:hover {
                transform: translateY(-1px);
                box-shadow: 0 8px 20px rgba(78, 54, 40, 0.14);
            }
            .narrative-title {
                margin: 0 0 8px 0;
                font-size: 1.02rem;
                font-weight: 800;
                color: var(--coffee-espresso);
            }
            .narrative-body {
                margin: 0;
                font-size: 0.93rem;
                line-height: 1.5;
                color: #5f493c;
            }
            .about-card {
                background: #fffaf3;
                border: 1px solid #dfccb4;
                border-radius: 12px;
                padding: 14px 16px;
                margin-bottom: 10px;
                box-shadow: 0 1px 6px rgba(78, 54, 40, 0.08);
                transition: transform 0.18s ease, box-shadow 0.18s ease, border-color 0.18s ease;
            }
            .about-card:hover {
                transform: translateY(-2px);
                box-shadow: 0 8px 20px rgba(78, 54, 40, 0.14);
                border-color: #cba780;
            }
            .about-title {
                margin: 0 0 6px 0;
                color: var(--coffee-roast);
                font-size: 1.0rem;
                font-weight: 800;
            }
            .about-text {
                margin: 0;
                color: #5f493c;
                line-height: 1.45;
                font-size: 0.92rem;
            }
            .cta-box {
                border: 1px solid #d2b08a;
                background: linear-gradient(180deg, #faeddc 0%, #f3dfc5 100%);
                border-radius: 12px;
                padding: 14px 16px;
                margin-top: 8px;
            }
            .cta-title {
                margin: 0 0 4px 0;
                color: var(--coffee-roast);
                font-size: 1rem;
                font-weight: 800;
            }
            .cta-text {
                margin: 0;
                color: #644b3c;
                font-size: 0.92rem;
            }
            .proponent-name {
                margin: 10px 0 4px 0;
                font-weight: 800;
                color: var(--coffee-roast);
                font-size: 1.02rem;
            }
            .proponent-role {
                margin: 0;
                color: #6a5242;
                font-size: 0.89rem;
                line-height: 1.45;
            }
            .proponent-note {
                margin-top: 10px;
                font-size: 0.78rem;
                color: #8a6e59;
                border-top: 1px solid #e6d6c4;
                padding-top: 8px;
            }
            .proponent-uniform-card {
                height: 430px;
                border: 1px solid #dcc4a7;
                border-radius: 12px;
                padding: 10px 10px 12px 10px;
                background: #fff9f1;
                box-shadow: 0 1px 6px rgba(78, 54, 40, 0.08);
                display: flex;
                flex-direction: column;
                transition: transform 0.18s ease, box-shadow 0.18s ease, border-color 0.18s ease;
            }
            .proponent-uniform-card:hover {
                transform: translateY(-2px);
                box-shadow: 0 10px 24px rgba(78, 54, 40, 0.16);
                border-color: #cba780;
            }
            .proponent-uniform-img-wrap {
                height: 210px;
                width: 100%;
                border-radius: 9px;
                overflow: hidden;
                border: 1px solid #e1ccb0;
                background: #f4e4d1;
                margin-bottom: 9px;
            }
            .proponent-uniform-img {
                width: 100%;
                height: 100%;
                object-fit: cover;
                object-position: center top;
                display: block;
            }
            .proponent-uniform-name {
                margin: 2px 0 4px 0;
                font-weight: 800;
                color: var(--coffee-roast);
                font-size: 0.96rem;
                line-height: 1.25;
                min-height: 40px;
            }
            .proponent-uniform-role {
                margin: 0;
                color: #694f40;
                font-size: 0.84rem;
                line-height: 1.43;
                flex: 1;
            }
            .proponent-uniform-note {
                margin-top: 8px;
                font-size: 0.74rem;
                color: #8a6e59;
                border-top: 1px solid #e4d3c0;
                padding-top: 7px;
            }
            div[data-testid="stMetric"] {
                border: 1px solid #dbc4a8;
                border-radius: 12px;
                padding: 10px 12px;
                background: #fff8ef;
                transition: transform 0.18s ease, box-shadow 0.18s ease;
            }
            div[data-testid="stMetric"]:hover {
                transform: translateY(-2px);
                box-shadow: 0 6px 16px rgba(78, 54, 40, 0.12);
            }
            .stTabs [data-baseweb="tab-list"] {
                gap: 8px;
            }
            .stTabs [data-baseweb="tab"] {
                background: #f0dfca;
                border-radius: 10px;
                padding: 0 14px;
                height: 42px;
                border: 1px solid #d8bf9f;
                color: var(--coffee-roast);
                transition: transform 0.14s ease, background 0.14s ease, border-color 0.14s ease, box-shadow 0.14s ease;
            }
            .stTabs [data-baseweb="tab"]:hover {
                transform: translateY(-1px);
                border-color: #c79b6d;
                background: #f6e8d5;
                box-shadow: 0 4px 10px rgba(78, 54, 40, 0.1);
            }
            .stTabs [aria-selected="true"] {
                background: var(--coffee-mocha);
                color: #fff8ef;
                border-color: var(--coffee-mocha);
            }
            .stButton > button {
                border-radius: 10px;
                border: 1px solid #c9a882;
                background: #f7e8d4;
                color: var(--coffee-roast);
                font-weight: 650;
                transition: transform 0.14s ease, box-shadow 0.14s ease, border-color 0.14s ease;
            }
            .stButton > button:hover {
                border-color: var(--coffee-caramel);
                color: var(--coffee-espresso);
                transform: translateY(-1px);
                box-shadow: 0 4px 10px rgba(78, 54, 40, 0.14);
            }
            .stButton > button[kind="primary"],
            .stDownloadButton > button {
                background: linear-gradient(180deg, #8a5e34 0%, var(--coffee-mocha) 100%);
                color: #fff9f0;
                border: 1px solid #6a472d;
            }
            .stButton > button[kind="primary"]:hover,
            .stDownloadButton > button:hover {
                filter: brightness(1.05);
            }
            [data-baseweb="tag"] {
                background: #ead3b8 !important;
                border: 1px solid #d2b18a !important;
                color: var(--coffee-roast) !important;
            }
            .sticky-header-bar {
                position: sticky;
                top: 3.25rem;
                z-index: 998;
                margin: 0 0 14px 0;
                padding: 10px 14px 9px 14px;
                border-radius: 12px;
                border: 1px solid #d8bf9f;
                border-left: 4px solid var(--coffee-caramel);
                background: rgba(255, 248, 237, 0.95);
                backdrop-filter: blur(6px);
                box-shadow: 0 2px 8px rgba(70, 49, 37, 0.12);
            }
            .sticky-main {
                margin: 0;
                font-size: 1.55rem;
                font-weight: 800;
                color: var(--coffee-espresso);
                line-height: 1.15;
            }
            .sticky-h2 {
                margin: 5px 0 0 0;
                font-size: 0.96rem;
                font-weight: 650;
                color: var(--coffee-roast);
                line-height: 1.2;
            }
            .sticky-h4 {
                margin: 4px 0 0 0;
                font-size: 0.82rem;
                font-weight: 550;
                color: var(--coffee-latte);
                line-height: 1.2;
            }
            .sticky-divider {
                margin-top: 8px;
                height: 1px;
                background: linear-gradient(90deg, #cfae87 0%, rgba(207, 174, 135, 0.2) 100%);
            }
            .hero-banner {
                margin: 4px 0 14px 0;
                padding: 22px 22px;
                border-radius: 18px;
                border: 1px solid #3f1f0f;
                background: linear-gradient(120deg, #2a0f05 0%, #3a1407 52%, #231008 100%);
                box-shadow: 0 10px 24px rgba(30, 13, 6, 0.32);
                position: relative;
                overflow: hidden;
            }
            .hero-banner::after {
                content: "";
                position: absolute;
                right: -38px;
                top: -38px;
                width: 140px;
                height: 140px;
                border-radius: 999px;
                background: radial-gradient(circle, rgba(222,154,99,0.28) 0%, rgba(222,154,99,0.04) 70%);
            }
            .hero-title {
                margin: 0;
                font-family: var(--font-fun);
                font-size: 4.2rem;
                line-height: 0.96;
                letter-spacing: 0.015em;
                position: relative;
                z-index: 1;
                font-weight: 800;
            }
            @media (max-width: 820px) {
                .hero-title {
                    font-size: 3.15rem;
                }
            }
            .hero-word-coffee {
                color: #de9a63;
                text-shadow:
                    0 3px 0 #8a4f2a,
                    0 8px 18px rgba(88, 56, 37, 0.36);
            }
            .hero-word-gpt {
                color: #fff6ea;
                margin-left: 0.18rem;
                text-shadow:
                    0 3px 0 #6a655f,
                    0 8px 18px rgba(70, 58, 49, 0.30);
            }
            .hero-sub {
                margin: 6px 0 0 0;
                font-size: 1.08rem;
                color: #fff6ea;
                font-weight: 800;
                position: relative;
                z-index: 1;
            }
            .hero-team {
                margin: 7px 0 0 0;
                font-size: 0.98rem;
                color: #fff6ea;
                font-weight: 700;
                letter-spacing: 0.015em;
                position: relative;
                z-index: 1;
            }
            .top-menu-shell {
                margin: 2px 0 10px 0;
                padding: 9px 12px;
                border-radius: 12px;
                border: 1px solid #ddc6aa;
                background: rgba(255, 248, 237, 0.9);
                box-shadow: 0 3px 10px rgba(72, 52, 39, 0.08);
            }
            .top-menu-title {
                margin: 0;
                font-size: 0.82rem;
                letter-spacing: 0.06em;
                text-transform: uppercase;
                color: #7e614f;
                font-weight: 800;
            }
            div[data-testid="stPageLink"] a {
                border: 1px solid #cba780;
                border-radius: 999px;
                background: #f8ebda;
                color: #4b3329 !important;
                font-weight: 700;
                padding: 0.42rem 0.95rem;
                transition: all 0.15s ease;
            }
            div[data-testid="stPageLink"] a:hover {
                background: #f4dfc3;
                border-color: #b67a3c;
                transform: translateY(-1px);
            }
        </style>
        """,
        unsafe_allow_html=True,
    )


def render_top_menu(active: str = "home"):
    st.markdown(
        """
        <div class="top-menu-shell">
            <p class="top-menu-title">Page Navigator</p>
        </div>
        """,
        unsafe_allow_html=True,
    )
    c1, c2, _ = st.columns([1.3, 2.1, 6.6])
    if hasattr(st, "page_link"):
        with c1:
            st.page_link("app.py", label="Home", use_container_width=True)
        with c2:
            st.page_link("pages/Model_Comparison.py", label="Model Comparison", use_container_width=True)
    else:
        st.markdown("[Home](./) | [Model Comparison](./Model_Comparison)")
    st.caption(f"Current Page: {'Home' if active == 'home' else 'Model Comparison'}")
    st.markdown("---")


def render_home_banner():
    st.markdown(
        """
        <div class="hero-banner">
            <h1 class="hero-title">
                <span class="hero-word-coffee">Brew</span><span class="hero-word-gpt">GPT</span>
            </h1>
            <p class="hero-sub">A Machine Learning Project</p>
            <p class="hero-team">Altonaga- Sarceda- Sunga - Torres</p>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_scrollable_html_table(table_html: str, max_height: int = 420):
    html = (
        "<div style='"
        "overflow-x:auto;"
        "overflow-y:auto;"
        f"max-height:{max_height}px;"
        "border:1px solid #e2d4c3;"
        "border-radius:10px;"
        "padding:4px;"
        "background:#fffaf4;"
        "box-shadow: inset 0 1px 3px rgba(0,0,0,0.06);"
        "'>"
        f"{table_html}"
        "</div>"
    )
    st.markdown(html, unsafe_allow_html=True)


def render_kpi_card(title: str, value: str, subtitle: str):
    st.markdown(
        f"""
        <div class="dashboard-card">
            <div class="kpi-title">{title}</div>
            <div class="kpi-value">{value}</div>
            <div class="kpi-sub">{subtitle}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_section_head(text: str, icon: str):
    st.markdown(
        f"""
        <div class="section-head">
            <span class="material-symbols-rounded head-icon">{icon}</span>
            <span>{text}</span>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_tab_banner(title: str, subtitle: str, icon: str):
    st.markdown(
        f"""
        <div class="tab-banner">
            <span class="material-symbols-rounded tab-banner-icon">{icon}</span>
            <div>
                <p class="tab-banner-title">{title}</p>
                <p class="tab-banner-sub">{subtitle}</p>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_project_narrative():
    st.markdown(
        """
        <div class="narrative-card">
            <p class="narrative-title">Project Narrative: COFFEE - CoffeeGPT</p>
            <p class="narrative-body">
                Coffee is personal, but brewing decisions are often still based on trial and error.
                This project translates taste preferences like sweet, nutty, bright, or smooth into one practical recipe.
                It helps teams move from guesswork to guided personalization, improving consistency, customer satisfaction,
                and loyalty while supporting baristas and coffee experts with better decision tools.
            </p>
        </div>
        """,
        unsafe_allow_html=True,
    )
    with st.expander("Why Stakeholders Should Be Involved"):
        st.markdown(
            """
            - Better customer experience through personalized coffee outcomes.
            - Stronger retention and brand differentiation.
            - Less waste and fewer failed brew iterations.
            - A scalable platform for training, product development, and innovation.
            """
        )


def render_about_project_page():
    st.caption("A concise, stakeholder-facing view of why this initiative matters.")

    c1, c2 = st.columns(2, gap="large")

    with c1:
        st.markdown(
            """
            <div class="about-card">
                <p class="about-title">1) Problem</p>
                <p class="about-text">
                    Coffee preference is highly personal, but brew execution is often based on manual trial-and-error.
                    This creates inconsistent outcomes, slower service adjustments, and missed opportunities to improve customer loyalty.
                </p>
            </div>
            """,
            unsafe_allow_html=True,
        )
        st.markdown(
            """
            <div class="about-card">
                <p class="about-title">2) Solution</p>
                <p class="about-text">
                    Our machine learning system converts preferred taste profiles into one practical recipe.
                    Teams can align brewing decisions with desired sensory outcomes faster and more consistently.
                </p>
            </div>
            """,
            unsafe_allow_html=True,
        )

    with c2:
        st.markdown(
            """
            <div class="about-card">
                <p class="about-title">3) Business Value</p>
                <p class="about-text">
                    The platform supports personalization at scale, improves quality consistency, reduces waste from failed iterations,
                    and strengthens customer retention through more reliable coffee experiences.
                </p>
            </div>
            """,
            unsafe_allow_html=True,
        )
        st.markdown(
            """
            <div class="about-card">
                <p class="about-title">4) Why This Is Strategic</p>
                <p class="about-text">
                    Beyond recipe recommendation, this can evolve into an innovation engine for barista training,
                    menu design, product development, and data-driven quality assurance.
                </p>
            </div>
            """,
            unsafe_allow_html=True,
        )

    st.markdown(
        """
        <div class="cta-box">
            <p class="cta-title">Pilot Partnership Call-to-Action</p>
            <p class="cta-text">
                We are inviting partner cafés, roasters, and coffee teams to run a pilot:
                compare recommended recipes against baseline methods, gather sensory feedback,
                and quantify operational and customer impact together.
            </p>
        </div>
        """,
        unsafe_allow_html=True,
    )

    st.markdown(
        """
        **Suggested Pilot Scope (4-8 weeks):**
        - Select target taste profiles and baseline recipes.
        - Run controlled tasting sessions and collect ratings.
        - Track consistency, satisfaction, and process efficiency.
        - Review outcomes and agree on rollout steps.
        """
    )


@st.cache_data(show_spinner=False)
def image_file_to_data_uri(path: str):
    ext = os.path.splitext(path)[1].lower()
    mime_map = {
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".png": "image/png",
        ".webp": "image/webp",
        ".bmp": "image/bmp",
    }
    mime = mime_map.get(ext, "image/jpeg")
    try:
        with open(path, "rb") as f:
            encoded = base64.b64encode(f.read()).decode("utf-8")
        return f"data:{mime};base64,{encoded}"
    except Exception:
        return None


def render_proponents_page():
    st.caption("The team behind COFFEE- Just the Way You Are")
    st.markdown("From beans to bytes, this team turns taste preferences into personalized coffee recipes.")

    cols = st.columns(4, gap="medium")
    for idx, p in enumerate(PROPONENTS):
        with cols[idx % 4]:
            data_uri = image_file_to_data_uri(p["image"])
            if data_uri is None:
                with st.container(border=True):
                    st.warning(f"Image not found: {p['image']}")
                    st.markdown(f"**{p['name']}**")
                    st.caption(p["role"])
                continue

            st.markdown(
                f"""
                <div class="proponent-uniform-card">
                    <div class="proponent-uniform-img-wrap">
                        <img class="proponent-uniform-img" src="{data_uri}" alt="{p["name"]}">
                    </div>
                    <p class="proponent-uniform-name">{p["name"]}</p>
                    <p class="proponent-uniform-role">{p["role"]}</p>
                    <p class="proponent-uniform-note">Asian Institute of Management<br>Masters of Data Science 2026</p>
                </div>
                """,
                unsafe_allow_html=True,
            )


def render_sticky_header():
    st.markdown(
        """
        <div class="sticky-header-bar">
            <p class="sticky-main">COFFEE- Just the Way You Are</p>
            <p class="sticky-h2">A Machine Learning Project</p>
            <p class="sticky-h4">Altonaga- Sarceda- Sunga - Torres</p>
            <div class="sticky-divider"></div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def slugify(text: str) -> str:
    clean = re.sub(r"[^a-zA-Z0-9]+", "_", text.strip())
    return clean.strip("_").lower() or "recipe"


def expected_calibration_error(y_true, y_prob, n_bins=10):
    y_true = np.asarray(y_true, dtype=float)
    y_prob = np.asarray(y_prob, dtype=float)
    if y_true.size == 0:
        return np.nan

    bins = np.linspace(0.0, 1.0, n_bins + 1)
    binned = np.digitize(y_prob, bins, right=True) - 1
    binned = np.clip(binned, 0, n_bins - 1)

    ece = 0.0
    for i in range(n_bins):
        mask = binned == i
        if not mask.any():
            continue
        confidence = y_prob[mask].mean()
        accuracy = y_true[mask].mean()
        ece += np.abs(confidence - accuracy) * (mask.sum() / y_true.size)
    return float(ece)


def positive_proba(model, x):
    if not hasattr(model, "predict_proba"):
        pred = np.asarray(model.predict(x)).reshape(-1)
        return np.clip(pred, 0.0, 1.0)

    proba = np.asarray(model.predict_proba(x))
    if proba.ndim == 1:
        return np.clip(proba, 0.0, 1.0)

    classes = getattr(model, "classes_", None)
    if proba.shape[1] == 1:
        if classes is not None and len(classes) == 1 and int(classes[0]) == 1:
            return np.ones(proba.shape[0], dtype=float)
        return np.zeros(proba.shape[0], dtype=float)

    if classes is not None:
        idx = np.where(np.asarray(classes) == 1)[0]
        if idx.size > 0:
            return proba[:, int(idx[0])]

    return proba[:, 1]


def make_stage1_model(algorithm, random_state):
    if algorithm in ("RandomForest", "GradientBoosting"):
        return RandomForestRegressor(
            n_estimators=220,
            max_depth=12,
            min_samples_leaf=2,
            random_state=random_state,
            n_jobs=1,
        )
    if algorithm == "XGBoost":
        return XGBRegressor(
            n_estimators=260,
            max_depth=4,
            learning_rate=0.05,
            subsample=0.9,
            colsample_bytree=0.9,
            objective="reg:squarederror",
            random_state=random_state,
            n_jobs=1,
        )
    if algorithm == "NeuralNetwork":
        return Pipeline(
            [
                ("scaler", StandardScaler()),
                (
                    "mlp",
                    MLPRegressor(
                        hidden_layer_sizes=(64, 32),
                        activation="relu",
                        alpha=1e-4,
                        learning_rate_init=1e-3,
                        max_iter=450,
                        early_stopping=True,
                        random_state=random_state,
                    ),
                ),
            ]
        )
    raise ValueError(f"Unknown algorithm: {algorithm}")


def make_stage2_model(algorithm, random_state):
    if algorithm == "RandomForest":
        return RandomForestClassifier(
            n_estimators=160,
            max_depth=10,
            min_samples_leaf=2,
            class_weight="balanced_subsample",
            random_state=random_state,
            n_jobs=1,
        )
    if algorithm == "GradientBoosting":
        return GradientBoostingClassifier(
            n_estimators=220,
            learning_rate=0.05,
            max_depth=2,
            subsample=0.85,
            random_state=random_state,
        )
    if algorithm == "XGBoost":
        return XGBClassifier(
            n_estimators=260,
            max_depth=4,
            learning_rate=0.05,
            subsample=0.9,
            colsample_bytree=0.9,
            objective="binary:logistic",
            eval_metric="logloss",
            random_state=random_state,
            n_jobs=1,
        )
    if algorithm == "NeuralNetwork":
        return Pipeline(
            [
                ("scaler", StandardScaler()),
                (
                    "mlp",
                    MLPClassifier(
                        hidden_layer_sizes=(64, 32),
                        activation="relu",
                        alpha=1e-4,
                        learning_rate_init=1e-3,
                        max_iter=450,
                        early_stopping=True,
                        random_state=random_state,
                    ),
                ),
            ]
        )
    raise ValueError(f"Unknown algorithm: {algorithm}")


def evaluate_model_quality(df, algorithm="RandomForest"):
    test_size = 0.25 if len(df) >= 80 else 0.33
    train_df, test_df = train_test_split(df, test_size=test_size, random_state=42, shuffle=True)

    stage1_eval = {}
    process_pred_test = pd.DataFrame(index=test_df.index)
    reg_rows = []

    for i, pcol in enumerate(PROCESS_COLS):
        reg = make_stage1_model(algorithm, random_state=500 + i)
        reg.fit(train_df[CONTROLLABLE_COLS], train_df[pcol])
        stage1_eval[pcol] = reg
        y_pred = reg.predict(test_df[CONTROLLABLE_COLS])
        process_pred_test[pcol] = y_pred

        y_true = test_df[pcol].values
        reg_rows.append(
            {
                "ProcessMetric": pcol,
                "MAE": float(mean_absolute_error(y_true, y_pred)),
                "RMSE": float(np.sqrt(mean_squared_error(y_true, y_pred))),
                "R2": float(r2_score(y_true, y_pred)),
            }
        )

    x2_train = train_df[CONTROLLABLE_COLS + PROCESS_COLS]
    x2_test = pd.concat([test_df[CONTROLLABLE_COLS], process_pred_test[PROCESS_COLS]], axis=1)

    cls_rows = []
    for j, tcol in enumerate(TASTE_COLS):
        clf = make_stage2_model(algorithm, random_state=700 + j)
        clf.fit(x2_train, train_df[tcol])
        y_true = test_df[tcol].astype(int).values
        y_prob = positive_proba(clf, x2_test)
        y_pred = (y_prob >= 0.5).astype(int)

        auc = np.nan
        if np.unique(y_true).size > 1:
            auc = float(roc_auc_score(y_true, y_prob))

        cls_rows.append(
            {
                "Taste": tcol,
                "AUC": auc,
                "F1": float(f1_score(y_true, y_pred, zero_division=0)),
                "Brier": float(brier_score_loss(y_true, y_prob)),
                "ECE_10bin": expected_calibration_error(y_true, y_prob, n_bins=10),
                "PositiveRate": float(np.mean(y_true)),
            }
        )

    cls_df = pd.DataFrame(cls_rows).sort_values("AUC", ascending=False, na_position="last")
    reg_df = pd.DataFrame(reg_rows).sort_values("RMSE", ascending=True)

    summary = {
        "MacroAUC": float(np.nanmean(cls_df["AUC"])) if not cls_df.empty else np.nan,
        "MacroF1": float(np.nanmean(cls_df["F1"])) if not cls_df.empty else np.nan,
        "MeanBrier": float(np.nanmean(cls_df["Brier"])) if not cls_df.empty else np.nan,
        "MeanECE": float(np.nanmean(cls_df["ECE_10bin"])) if not cls_df.empty else np.nan,
        "MeanMAE": float(np.nanmean(reg_df["MAE"])) if not reg_df.empty else np.nan,
        "MeanRMSE": float(np.nanmean(reg_df["RMSE"])) if not reg_df.empty else np.nan,
        "MeanR2": float(np.nanmean(reg_df["R2"])) if not reg_df.empty else np.nan,
    }
    return {"classification": cls_df, "regression": reg_df, "summary": summary}


@st.cache_resource(show_spinner=True)
def load_and_train_models(path: str, algorithm: str = "RandomForest"):
    raw_df = pd.read_csv(path)
    required_cols = sorted(set(TASTE_COLS + CONTROLLABLE_COLS + PROCESS_COLS))
    df = raw_df[required_cols].dropna().copy()

    stage1 = {}
    for i, pcol in enumerate(PROCESS_COLS):
        reg = make_stage1_model(algorithm, random_state=100 + i)
        reg.fit(df[CONTROLLABLE_COLS], df[pcol])
        stage1[pcol] = reg

    stage2 = {}
    x2 = df[CONTROLLABLE_COLS + PROCESS_COLS]
    for j, tcol in enumerate(TASTE_COLS):
        clf = make_stage2_model(algorithm, random_state=200 + j)
        clf.fit(x2, df[tcol])
        stage2[tcol] = clf

    controllable_bounds = {
        c: (float(df[c].quantile(0.01)), float(df[c].quantile(0.99)))
        for c in CONTROLLABLE_COLS
    }
    allowed_dose = np.array(sorted(df["Dose"].unique().tolist()), dtype=float)
    allowed_grind = np.array(sorted(df["Grind"].unique().tolist()), dtype=int)

    scaler = StandardScaler().fit(df[CONTROLLABLE_COLS])
    nn = NearestNeighbors(n_neighbors=1)
    nn.fit(scaler.transform(df[CONTROLLABLE_COLS]))

    quality = evaluate_model_quality(df, algorithm=algorithm)

    return {
        "df": df,
        "stage1": stage1,
        "stage2": stage2,
        "controllable_bounds": controllable_bounds,
        "allowed_dose": allowed_dose,
        "allowed_grind": allowed_grind,
        "scaler": scaler,
        "nn": nn,
        "quality": quality,
        "algorithm": algorithm,
    }


def normalize_weights(selected_tastes, weight_map):
    s = pd.Series({t: float(weight_map.get(t, 0.0)) for t in selected_tastes}, index=selected_tastes)
    if (s < 0).any() or float(s.sum()) <= 0:
        raise ValueError("Taste weights must be non-negative and sum to > 0.")
    return s / s.sum()


def default_constraints(assets):
    bounds = assets["controllable_bounds"]
    return {
        "Volume": {"min": float(bounds["Volume"][0]), "max": float(bounds["Volume"][1])},
        "Brew Temperature": {"min": float(bounds["Brew Temperature"][0]), "max": float(bounds["Brew Temperature"][1])},
        "Pour Temp": {"min": float(bounds["Pour Temp"][0]), "max": float(bounds["Pour Temp"][1])},
        "Dose": {"allowed": [float(x) for x in assets["allowed_dose"].tolist()]},
        "Grind": {"allowed": [int(x) for x in assets["allowed_grind"].tolist()]},
    }


def _filter_numeric_allowed(base_values, selected_values, value_type=float):
    if selected_values is None:
        return base_values
    selected_values = np.array(selected_values, dtype=value_type)
    if selected_values.size == 0:
        return np.array([], dtype=base_values.dtype)
    if value_type is int:
        mask = np.isin(base_values.astype(int), selected_values.astype(int))
    else:
        mask = np.isclose(base_values[:, None], selected_values[None, :], atol=1e-6).any(axis=1)
    return base_values[mask]


def sample_candidates(n_samples, bounds, allowed_dose, allowed_grind, constraints=None, random_state=42):
    rng = np.random.default_rng(random_state)
    constraints = constraints or {}

    dose_choices = _filter_numeric_allowed(
        allowed_dose.astype(float),
        constraints.get("Dose", {}).get("allowed"),
        value_type=float,
    )
    grind_choices = _filter_numeric_allowed(
        allowed_grind.astype(int),
        constraints.get("Grind", {}).get("allowed"),
        value_type=int,
    )
    if dose_choices.size == 0:
        raise ValueError("Constraint error: no valid Dose values selected.")
    if grind_choices.size == 0:
        raise ValueError("Constraint error: no valid Grind values selected.")

    frames = []
    total = 0
    attempts = 0
    while total < n_samples and attempts < 8:
        attempts += 1
        draw_size = max(2000, int((n_samples - total) * 1.8))
        data = {}

        for c in CONTROLLABLE_COLS:
            if c in ("Dose", "Grind"):
                continue
            base_lo, base_hi = bounds[c]
            cfg = constraints.get(c, {})
            lo = max(float(base_lo), float(cfg.get("min", base_lo)))
            hi = min(float(base_hi), float(cfg.get("max", base_hi)))
            if lo >= hi:
                raise ValueError(f"Constraint error: {c} has invalid range ({lo}, {hi}).")
            data[c] = rng.uniform(lo, hi, size=draw_size)

        data["Dose"] = rng.choice(dose_choices, size=draw_size)
        data["Grind"] = rng.choice(grind_choices, size=draw_size)

        cand = pd.DataFrame(data)[CONTROLLABLE_COLS]
        cand["Volume"] = np.round(cand["Volume"] / 0.1) * 0.1
        cand["Brew Temperature"] = np.round(cand["Brew Temperature"] / 0.1) * 0.1
        cand["Pour Temp"] = np.round(cand["Pour Temp"] / 0.1) * 0.1
        cand["Dose"] = np.round(cand["Dose"] / 0.1) * 0.1
        cand["Grind"] = cand["Grind"].astype(int)

        # Physical rule: brew temp should not be lower than pour temp.
        cand = cand[cand["Brew Temperature"] >= cand["Pour Temp"]]
        if cand.empty:
            continue

        frames.append(cand)
        total += len(cand)

    if not frames:
        raise ValueError("No candidate recipes remain after applying constraints.")

    out = pd.concat(frames, ignore_index=True)
    out = out.drop_duplicates(subset=CONTROLLABLE_COLS)
    if out.empty:
        raise ValueError("No unique candidate recipes remain after applying constraints.")
    return out.head(n_samples).reset_index(drop=True)


def predict_two_stage(candidates, stage1, stage2):
    process_pred = pd.DataFrame(index=candidates.index)
    for pcol in PROCESS_COLS:
        process_pred[pcol] = stage1[pcol].predict(candidates[CONTROLLABLE_COLS])

    x2 = pd.concat([candidates[CONTROLLABLE_COLS], process_pred[PROCESS_COLS]], axis=1)
    taste_prob = pd.DataFrame(index=candidates.index)
    for tcol in TASTE_COLS:
        taste_prob[tcol] = positive_proba(stage2[tcol], x2)

    return process_pred, taste_prob


def distance_penalty(candidates, scaler, nn):
    scaled = scaler.transform(candidates[CONTROLLABLE_COLS])
    dist, _ = nn.kneighbors(scaled, n_neighbors=1)
    return dist[:, 0]


def local_tree_uncertainty(stage2_models, x2_row, selected_tastes, normalized_weights):
    weighted_tree_prob = None
    per_taste_rows = []
    rng = np.random.default_rng(42)
    x2_np = x2_row.to_numpy(dtype=float)
    n_draws = 40
    noise_scale = 0.03

    for t in selected_tastes:
        clf = stage2_models[t]
        base_prob = float(positive_proba(clf, x2_row)[0])
        scale = np.maximum(np.abs(x2_np[0]) * noise_scale, 1e-3)
        draws = rng.normal(loc=x2_np[0], scale=scale, size=(n_draws, x2_np.shape[1]))
        draws_df = pd.DataFrame(draws, columns=x2_row.columns)
        sampled_probs = positive_proba(clf, draws_df)
        tree_probs = np.concatenate([np.array([base_prob], dtype=float), np.asarray(sampled_probs, dtype=float)])
        w = float(normalized_weights[t])
        if weighted_tree_prob is None:
            weighted_tree_prob = np.zeros_like(tree_probs)
        weighted_tree_prob += w * tree_probs
        per_taste_rows.append(
            {
                "Taste": t,
                "MeanProb": float(tree_probs.mean()),
                "StdProb": float(tree_probs.std(ddof=0)),
                "P10": float(np.percentile(tree_probs, 10)),
                "P90": float(np.percentile(tree_probs, 90)),
            }
        )

    if weighted_tree_prob is None:
        weighted_tree_prob = np.array([0.0], dtype=float)
    return {
        "WeightedMean": float(weighted_tree_prob.mean()),
        "WeightedStd": float(weighted_tree_prob.std(ddof=0)),
        "WeightedP10": float(np.percentile(weighted_tree_prob, 10)),
        "WeightedP90": float(np.percentile(weighted_tree_prob, 90)),
        "per_taste_df": pd.DataFrame(per_taste_rows),
    }


def optimize_recipe(
    selected_tastes,
    weight_map,
    assets,
    n_candidates=12000,
    non_selected_penalty=0.20,
    distance_weight=0.08,
    constraints=None,
    top_k=3,
    random_state=42,
):
    selected_tastes = list(selected_tastes)
    if not selected_tastes:
        raise ValueError("Select at least one taste profile.")

    invalid = [t for t in selected_tastes if t not in TASTE_COLS]
    if invalid:
        raise ValueError(f"Unknown taste(s): {invalid}")

    weights = normalize_weights(selected_tastes, weight_map)

    cand = sample_candidates(
        n_samples=n_candidates,
        bounds=assets["controllable_bounds"],
        allowed_dose=assets["allowed_dose"],
        allowed_grind=assets["allowed_grind"],
        constraints=constraints,
        random_state=random_state,
    )
    process_pred, taste_prob = predict_two_stage(cand, assets["stage1"], assets["stage2"])

    selected_score = taste_prob[selected_tastes].mul(weights, axis=1).sum(axis=1)
    non_selected = [t for t in TASTE_COLS if t not in selected_tastes]
    non_selected_mean = taste_prob[non_selected].mean(axis=1) if non_selected else 0.0
    dist = distance_penalty(cand, assets["scaler"], assets["nn"])

    objective = selected_score - non_selected_penalty * non_selected_mean - distance_weight * np.tanh(dist)

    ranked = cand.copy()
    ranked["CandidateIndex"] = cand.index
    ranked["SelectedTasteScore"] = selected_score.values
    ranked["NonSelectedMean"] = non_selected_mean if np.isscalar(non_selected_mean) else non_selected_mean.values
    ranked["DistanceToObserved"] = dist
    ranked["Objective"] = objective.values
    ranked = ranked.drop_duplicates(subset=CONTROLLABLE_COLS).sort_values("Objective", ascending=False).reset_index(drop=True)
    if ranked.empty:
        raise ValueError("No feasible recipe candidates found. Relax constraints and try again.")

    top_k = int(max(1, min(top_k, len(ranked))))
    top_ranked = ranked.head(top_k).copy()
    top_idx = top_ranked["CandidateIndex"].astype(int).tolist()

    recipes = top_ranked[
        CONTROLLABLE_COLS + ["SelectedTasteScore", "NonSelectedMean", "DistanceToObserved", "Objective"]
    ].reset_index(drop=True)
    processes = process_pred.loc[top_idx, PROCESS_COLS].reset_index(drop=True)
    tastes = taste_prob.loc[top_idx, TASTE_COLS].reset_index(drop=True)

    uncertainty_rows = []
    per_rank_taste_uncertainty = {}
    normalized_weights = weights.to_dict()
    for rank_pos, cand_idx in enumerate(top_idx):
        x2_row = pd.concat(
            [
                cand.loc[[cand_idx], CONTROLLABLE_COLS].reset_index(drop=True),
                process_pred.loc[[cand_idx], PROCESS_COLS].reset_index(drop=True),
            ],
            axis=1,
        )
        unc = local_tree_uncertainty(assets["stage2"], x2_row, selected_tastes, normalized_weights)
        uncertainty_rows.append(
            {
                "Rank": rank_pos + 1,
                "WeightedProbMean": unc["WeightedMean"],
                "WeightedProbStd": unc["WeightedStd"],
                "WeightedProbP10": unc["WeightedP10"],
                "WeightedProbP90": unc["WeightedP90"],
            }
        )
        per_rank_taste_uncertainty[rank_pos] = unc["per_taste_df"]

    uncertainty_df = pd.DataFrame(uncertainty_rows)
    best_obj = float(recipes.iloc[0]["Objective"])
    second_obj = float(recipes.iloc[1]["Objective"]) if len(recipes) > 1 else best_obj
    objective_gap = best_obj - second_obj if len(recipes) > 1 else np.nan
    objective_std = float(np.std(ranked["Objective"].values, ddof=0)) if len(ranked) > 1 else 0.0
    if np.isnan(objective_gap):
        confidence_index = 50.0
    else:
        confidence_index = float(100.0 / (1.0 + np.exp(-(objective_gap / (objective_std + 1e-9)))))

    return {
        "recipes": recipes,
        "processes": processes,
        "tastes": tastes,
        "used_weights": normalized_weights,
        "uncertainty": uncertainty_df,
        "per_rank_taste_uncertainty": per_rank_taste_uncertainty,
        "confidence": {
            "ObjectiveGap12": float(objective_gap) if not np.isnan(objective_gap) else np.nan,
            "ObjectiveStdAllCandidates": objective_std,
            "ConfidenceIndexPct": confidence_index,
            "TotalFeasibleCandidates": int(len(ranked)),
        },
    }


def build_export_table(label, selected_tastes, used_weights, recipe, process_row, taste_row):
    rows = []

    for t in selected_tastes:
        rows.append(
            {
                "RecipeLabel": label,
                "Section": "SelectedWeight",
                "Field": t,
                "Value": float(used_weights.get(t, 0.0)),
            }
        )

    recipe_cols = [
        c
        for c in CONTROLLABLE_COLS + ["SelectedTasteScore", "NonSelectedMean", "DistanceToObserved", "Objective"]
        if c in recipe.columns
    ]
    for c in recipe_cols:
        rows.append(
            {
                "RecipeLabel": label,
                "Section": "Recipe",
                "Field": c,
                "Value": float(recipe.iloc[0][c]),
            }
        )

    for c in PROCESS_COLS:
        rows.append(
            {
                "RecipeLabel": label,
                "Section": "PredictedProcess",
                "Field": c,
                "Value": float(process_row.iloc[0][c]),
            }
        )

    for t in TASTE_COLS:
        rows.append(
            {
                "RecipeLabel": label,
                "Section": "PredictedTasteProbability",
                "Field": t,
                "Value": float(taste_row.iloc[0][t]),
            }
        )

    return pd.DataFrame(rows)


def export_csv_bytes(export_df):
    return export_df.to_csv(index=False).encode("utf-8")


def _pdf_write_line(pdf, line, y):
    if y < 45:
        pdf.showPage()
        pdf.setFont("Helvetica", 10)
        y = 750
    pdf.drawString(40, y, str(line))
    return y - 14


def build_recipe_pdf_bytes(label, selected_tastes, used_weights, recipe, process_row, taste_row):
    if not REPORTLAB_AVAILABLE:
        return None

    buffer = io.BytesIO()
    pdf = canvas.Canvas(buffer, pagesize=letter)
    pdf.setTitle(f"Coffee Recipe - {label}")
    pdf.setFont("Helvetica-Bold", 14)
    pdf.drawString(40, 770, f"Coffee Recipe Recommendation: {label}")
    pdf.setFont("Helvetica", 10)

    y = 745
    y = _pdf_write_line(pdf, f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", y)

    y = _pdf_write_line(pdf, "", y)
    y = _pdf_write_line(pdf, "Selected Weights:", y)
    for t in selected_tastes:
        y = _pdf_write_line(pdf, f"  - {t}: {used_weights.get(t, 0.0):.4f}", y)

    y = _pdf_write_line(pdf, "", y)
    y = _pdf_write_line(pdf, "Recommended Recipe:", y)
    recipe_cols = [
        c
        for c in CONTROLLABLE_COLS + ["SelectedTasteScore", "NonSelectedMean", "DistanceToObserved", "Objective"]
        if c in recipe.columns
    ]
    for c in recipe_cols:
        y = _pdf_write_line(pdf, f"  - {c}: {float(recipe.iloc[0][c]):.6f}", y)

    y = _pdf_write_line(pdf, "", y)
    y = _pdf_write_line(pdf, "Predicted Process Outcomes:", y)
    for c in PROCESS_COLS:
        y = _pdf_write_line(pdf, f"  - {c}: {float(process_row.iloc[0][c]):.6f}", y)

    y = _pdf_write_line(pdf, "", y)
    y = _pdf_write_line(pdf, "Predicted Selected Taste Probabilities:", y)
    for t in selected_tastes:
        y = _pdf_write_line(pdf, f"  - {t}: {float(taste_row.iloc[0][t]):.6f}", y)

    pdf.save()
    buffer.seek(0)
    return buffer.getvalue()


def build_compare_pdf_bytes(label_a, export_a, label_b, export_b):
    if not REPORTLAB_AVAILABLE:
        return None

    buffer = io.BytesIO()
    pdf = canvas.Canvas(buffer, pagesize=letter)
    pdf.setTitle("Coffee Recipe Comparison")
    pdf.setFont("Helvetica-Bold", 14)
    pdf.drawString(40, 770, "Coffee Recipe Comparison")
    pdf.setFont("Helvetica", 10)
    y = 745

    y = _pdf_write_line(pdf, f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", y)

    for label, df in [(label_a, export_a), (label_b, export_b)]:
        y = _pdf_write_line(pdf, "", y)
        y = _pdf_write_line(pdf, label, y)
        for section in ["SelectedWeight", "Recipe", "PredictedProcess", "PredictedTasteProbability"]:
            y = _pdf_write_line(pdf, f"  {section}:", y)
            sec = df[df["Section"] == section]
            if section == "PredictedTasteProbability":
                sec = sec.sort_values("Value", ascending=False).head(8)
            for _, row in sec.iterrows():
                y = _pdf_write_line(pdf, f"    - {row['Field']}: {float(row['Value']):.6f}", y)

    pdf.save()
    buffer.seek(0)
    return buffer.getvalue()


def ensure_log_dir():
    os.makedirs(LOG_DIR, exist_ok=True)


def to_json_text(payload):
    def _default(obj):
        if isinstance(obj, (np.integer, np.floating)):
            return float(obj)
        return str(obj)

    return json.dumps(payload, default=_default)


def append_row_to_csv(path, row):
    ensure_log_dir()
    row_df = pd.DataFrame([row])
    if os.path.exists(path):
        old_df = pd.read_csv(path)
        cols = list(dict.fromkeys(old_df.columns.tolist() + row_df.columns.tolist()))
        out_df = pd.concat(
            [old_df.reindex(columns=cols), row_df.reindex(columns=cols)],
            ignore_index=True,
        )
    else:
        out_df = row_df
    out_df.to_csv(path, index=False)


def load_log_csv(path):
    if not os.path.exists(path):
        return pd.DataFrame()
    try:
        return pd.read_csv(path)
    except Exception:
        return pd.DataFrame()


def apply_scenario_preset(prefix, preset_name):
    preset = SCENARIO_PRESETS.get(preset_name)
    if not preset:
        return
    st.session_state[f"{prefix}_tastes"] = list(preset["tastes"])
    for t, w in preset["weights"].items():
        st.session_state[f"{prefix}_w_{slugify(t)}"] = int(w)
    st.session_state[f"{prefix}_cand"] = int(preset.get("n_candidates", 12000))
    st.session_state[f"{prefix}_nsp"] = float(preset.get("non_selected_penalty", 0.20))
    st.session_state[f"{prefix}_dist"] = float(preset.get("distance_weight", 0.08))


def collect_optimizer_controls(prefix, assets, defaults=None):
    if defaults is None:
        defaults = ["Sweet"]

    if f"{prefix}_tastes" not in st.session_state:
        st.session_state[f"{prefix}_tastes"] = list(defaults)

    render_section_head("Scenario Presets", "auto_awesome")
    preset_choice = st.selectbox(
        "Choose a starting scenario",
        options=list(SCENARIO_PRESETS.keys()),
        key=f"{prefix}_preset",
    )
    if st.button("Apply Preset", key=f"{prefix}_apply_preset", use_container_width=True):
        apply_scenario_preset(prefix, preset_choice)
        st.rerun()

    selected_tastes = st.multiselect("Taste profiles", TASTE_COLS, key=f"{prefix}_tastes")
    algorithm = st.selectbox(
        "Model algorithm",
        options=MODEL_ALGORITHMS,
        index=0,
        key=f"{prefix}_algorithm",
    )

    st.caption("Weights are normalized automatically.")
    weight_map = {}
    if selected_tastes:
        default_w = max(1, int(round(100 / len(selected_tastes))))
        for t in selected_tastes:
            safe_t = slugify(t)
            slider_key = f"{prefix}_w_{safe_t}"
            if slider_key not in st.session_state:
                st.session_state[slider_key] = default_w
            weight_map[t] = st.slider(
                f"{t} weight",
                min_value=0,
                max_value=100,
                step=1,
                key=slider_key,
            )

    top_k = st.slider(
        "Top recipes to keep",
        min_value=1,
        max_value=5,
        value=3,
        step=1,
        key=f"{prefix}_topk",
    )
    n_candidates = st.slider(
        "Search candidates",
        min_value=2000,
        max_value=30000,
        value=12000,
        step=1000,
        key=f"{prefix}_cand",
    )
    non_selected_penalty = st.slider(
        "Non-selected taste penalty",
        0.0,
        0.60,
        0.20,
        0.05,
        key=f"{prefix}_nsp",
    )
    distance_weight = st.slider(
        "Distance penalty",
        0.0,
        0.30,
        0.08,
        0.01,
        key=f"{prefix}_dist",
    )
    random_state = st.number_input(
        "Random seed",
        min_value=1,
        max_value=9999,
        value=42,
        step=1,
        key=f"{prefix}_seed",
    )

    constraints = {}
    base_constraints = default_constraints(assets)
    with st.expander("Recipe Constraints", expanded=False):
        st.caption("Constrain ranges to keep recipes operationally realistic.")
        for c in ["Volume", "Brew Temperature", "Pour Temp"]:
            base_lo = float(np.round(base_constraints[c]["min"], 1))
            base_hi = float(np.round(base_constraints[c]["max"], 1))
            if base_hi <= base_lo:
                base_hi = base_lo + 0.1
            rng = st.slider(
                f"{c} range",
                min_value=base_lo,
                max_value=base_hi,
                value=(base_lo, base_hi),
                step=0.1,
                key=f"{prefix}_rng_{slugify(c)}",
            )
            constraints[c] = {"min": float(rng[0]), "max": float(rng[1])}

        dose_options = [float(x) for x in assets["allowed_dose"].tolist()]
        grind_options = [int(x) for x in assets["allowed_grind"].tolist()]
        allowed_dose = st.multiselect(
            "Allowed Dose values",
            options=dose_options,
            default=dose_options,
            key=f"{prefix}_dose_allowed",
        )
        allowed_grind = st.multiselect(
            "Allowed Grind values",
            options=grind_options,
            default=grind_options,
            key=f"{prefix}_grind_allowed",
        )
        constraints["Dose"] = {"allowed": [float(x) for x in allowed_dose]}
        constraints["Grind"] = {"allowed": [int(x) for x in allowed_grind]}

    return {
        "algorithm": algorithm,
        "selected_tastes": selected_tastes,
        "weight_map": weight_map,
        "top_k": int(top_k),
        "n_candidates": int(n_candidates),
        "non_selected_penalty": float(non_selected_penalty),
        "distance_weight": float(distance_weight),
        "random_state": int(random_state),
        "constraints": constraints,
        "preset": preset_choice,
    }


def run_optimization(cfg, assets):
    selected_algorithm = cfg.get("algorithm", "RandomForest")
    active_assets = assets
    if assets.get("algorithm") != selected_algorithm:
        active_assets = load_and_train_models(DATA_PATH, algorithm=selected_algorithm)

    out = optimize_recipe(
        selected_tastes=cfg["selected_tastes"],
        weight_map=cfg["weight_map"],
        assets=active_assets,
        n_candidates=cfg["n_candidates"],
        non_selected_penalty=cfg["non_selected_penalty"],
        distance_weight=cfg["distance_weight"],
        constraints=cfg["constraints"],
        top_k=cfg["top_k"],
        random_state=cfg["random_state"],
    )
    out["algorithm"] = selected_algorithm
    return out


def _extract_shap_vector(shap_values):
    if isinstance(shap_values, list):
        arr = np.array(shap_values[-1])
    else:
        arr = np.array(shap_values)

    if arr.ndim == 3:
        class_idx = 1 if arr.shape[2] > 1 else 0
        return arr[0, :, class_idx]
    if arr.ndim == 2:
        return arr[0]
    if arr.ndim == 1:
        return arr
    return arr.reshape(-1)


def explain_recipe_local(assets, recipe, process_row, selected_tastes):
    x2_cols = CONTROLLABLE_COLS + PROCESS_COLS
    x2_row = pd.concat([recipe[CONTROLLABLE_COLS], process_row[PROCESS_COLS]], axis=1)[x2_cols].reset_index(drop=True)

    explanation_mode = {}
    explanation_rows = {}

    for taste in selected_tastes:
        clf = assets["stage2"][taste]
        used_shap = False

        if SHAP_AVAILABLE:
            try:
                explainer = shap.TreeExplainer(clf)
                shap_values = explainer.shap_values(x2_row)
                vals = _extract_shap_vector(shap_values)
                rows = pd.DataFrame({"Feature": x2_cols, "Contribution": vals})
                rows["AbsContribution"] = rows["Contribution"].abs()
                rows = rows.sort_values("AbsContribution", ascending=False)
                explanation_rows[taste] = rows
                explanation_mode[taste] = "SHAP"
                used_shap = True
            except Exception:
                used_shap = False

        if not used_shap:
            base_prob = float(clf.predict_proba(x2_row)[:, 1][0])
            contrib_rows = []
            for feat in x2_cols:
                base_val = float(x2_row.iloc[0][feat])
                delta = max(abs(base_val) * 0.05, 0.05)

                x_hi = x2_row.copy()
                x_lo = x2_row.copy()
                x_hi.at[0, feat] = base_val + delta
                x_lo.at[0, feat] = base_val - delta

                p_hi = float(clf.predict_proba(x_hi)[:, 1][0])
                p_lo = float(clf.predict_proba(x_lo)[:, 1][0])
                contrib_rows.append(
                    {
                        "Feature": feat,
                        "Contribution": 0.5 * (p_hi - p_lo),
                        "AbsContribution": abs(0.5 * (p_hi - p_lo)),
                        "BaseProb": base_prob,
                    }
                )

            rows = pd.DataFrame(contrib_rows).sort_values("AbsContribution", ascending=False)
            explanation_rows[taste] = rows
            explanation_mode[taste] = "Approximate"

    return {"mode": explanation_mode, "rows": explanation_rows}


def render_recipe_output(label, cfg, output_dict, key_prefix, assets):
    recipes = output_dict["recipes"].copy()
    processes = output_dict["processes"].copy()
    tastes = output_dict["tastes"].copy()
    used_weights = output_dict["used_weights"]
    uncertainty_df = output_dict["uncertainty"].copy()
    confidence = output_dict["confidence"]
    algorithm_used = output_dict.get("algorithm", assets.get("algorithm", "RandomForest"))

    st.markdown(f"### {label}")
    st.caption(f"Algorithm in use: {algorithm_used}")
    render_section_head("Top Candidate Recipes", "workspace_premium")
    top_table = recipes.copy()
    top_table.insert(0, "Rank", np.arange(1, len(top_table) + 1))
    st.dataframe(top_table.round(4), use_container_width=True, hide_index=True)

    rank_options = list(range(1, len(recipes) + 1))
    selected_rank = st.radio(
        "Inspect recipe rank",
        options=rank_options,
        horizontal=True,
        key=f"{key_prefix}_rank_picker",
    )
    selected_idx = int(selected_rank - 1)

    recipe = recipes.iloc[[selected_idx]].reset_index(drop=True)
    process_row = processes.iloc[[selected_idx]].reset_index(drop=True)
    taste_row = tastes.iloc[[selected_idx]].reset_index(drop=True)
    selected_prob_df = taste_row[cfg["selected_tastes"]].T.reset_index()
    selected_prob_df.columns = ["Taste", "Probability"]
    top_taste_row = selected_prob_df.sort_values("Probability", ascending=False).iloc[0]

    unc_row = uncertainty_df[uncertainty_df["Rank"] == selected_rank]
    unc_std = float(unc_row["WeightedProbStd"].iloc[0]) if not unc_row.empty else np.nan

    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Objective", f"{float(recipe.iloc[0]['Objective']):.4f}")
    m2.metric("Selected Taste Score", f"{float(recipe.iloc[0]['SelectedTasteScore']):.4f}")
    m3.metric("Confidence Index", f"{float(confidence['ConfidenceIndexPct']):.1f}%")
    m4.metric("Uncertainty (Std)", f"{unc_std:.4f}" if not np.isnan(unc_std) else "n/a")

    if label.strip().lower() == "single recipe":
        recommended_output = ", ".join([f"{c}={float(recipe.iloc[0][c]):.2f}" for c in CONTROLLABLE_COLS])
        st.markdown("### Recommended Output Settings")
        st.markdown(f"- **Taste Profile selected** -> {', '.join(cfg['selected_tastes'])}")
        st.markdown(f"- **Derived from Algorithm** -> {algorithm_used}")
        st.markdown(f"- **Output** -> {recommended_output}")

        recommended_table = pd.DataFrame(
            [
                {
                    "Taste Profile selected": ", ".join(cfg["selected_tastes"]),
                    "Derived from Algorithm": algorithm_used,
                    **{c: float(recipe.iloc[0][c]) for c in CONTROLLABLE_COLS},
                }
            ]
        )
        recommended_style = (
            recommended_table.style.format({c: "{:.2f}" for c in CONTROLLABLE_COLS})
            .set_caption("Recommended Output Settings (Best Algorithm)")
            .apply(lambda row: ["background-color: #dcfce7; font-weight: 700;" for _ in row], axis=1)
            .set_table_styles(
                [
                    {"selector": "caption", "props": "caption-side: top; font-size: 15px; font-weight: 700;"},
                    {"selector": "th", "props": "background-color: #0f172a; color: white; text-align: center;"},
                    {"selector": "td", "props": "text-align: center;"},
                ]
            )
        )
        render_scrollable_html_table(recommended_style.to_html(), max_height=220)

    upper_left, upper_right = st.columns([1.1, 1.2], gap="large")

    with upper_left:
        render_section_head("Normalized Weights", "weight")
        weight_df = pd.DataFrame({"Taste": list(used_weights.keys()), "Weight": list(used_weights.values())})
        st.dataframe(weight_df, use_container_width=True, hide_index=True)

        render_section_head("Recommended Controllable Recipe", "coffee_maker")
        st.dataframe(recipe.round(6), use_container_width=True, hide_index=True)

        render_section_head("Predicted Process Outcomes", "query_stats")
        st.dataframe(process_row.round(6), use_container_width=True, hide_index=True)

        render_section_head("Confidence & Uncertainty Detail", "shield")
        summary_df = pd.DataFrame(
            [
                {"Metric": "Objective Gap (Top1-Top2)", "Value": confidence["ObjectiveGap12"]},
                {"Metric": "Objective Std (all feasible)", "Value": confidence["ObjectiveStdAllCandidates"]},
                {"Metric": "Feasible Candidates", "Value": confidence["TotalFeasibleCandidates"]},
            ]
        )
        st.dataframe(summary_df, use_container_width=True, hide_index=True)
        if not unc_row.empty:
            st.caption(
                f"Rank {selected_rank} weighted-probability interval (P10-P90): "
                f"{float(unc_row['WeightedProbP10'].iloc[0]):.3f} to {float(unc_row['WeightedProbP90'].iloc[0]):.3f}"
            )
        rank_taste_unc = output_dict["per_rank_taste_uncertainty"].get(selected_idx, pd.DataFrame())
        if not rank_taste_unc.empty:
            st.dataframe(rank_taste_unc.round(6), use_container_width=True, hide_index=True)

    with upper_right:
        render_section_head("Predicted Selected Taste Probabilities", "insights")
        st.dataframe(selected_prob_df.round(6), use_container_width=True, hide_index=True)
        st.bar_chart(selected_prob_df.set_index("Taste"))

        with st.expander("Show full taste probability profile"):
            full_prob_df = taste_row[TASTE_COLS].T.reset_index()
            full_prob_df.columns = ["Taste", "Probability"]
            st.dataframe(full_prob_df.round(6), use_container_width=True, hide_index=True)

        render_section_head("Explain This Recipe", "psychology")
        explain = explain_recipe_local(assets, recipe, process_row, cfg["selected_tastes"])
        for taste in cfg["selected_tastes"]:
            rows = explain["rows"].get(taste, pd.DataFrame())
            if rows.empty:
                continue
            mode = explain["mode"].get(taste, "Approximate")
            with st.expander(f"{taste} feature contributions ({mode})", expanded=False):
                st.dataframe(rows[["Feature", "Contribution"]].round(6), use_container_width=True, hide_index=True)
                st.bar_chart(rows.set_index("Feature")[["Contribution"]].head(8))

    export_df = build_export_table(
        label=label,
        selected_tastes=cfg["selected_tastes"],
        used_weights=used_weights,
        recipe=recipe,
        process_row=process_row,
        taste_row=taste_row,
    )
    csv_bytes = export_csv_bytes(export_df)
    pdf_bytes = build_recipe_pdf_bytes(
        label=label,
        selected_tastes=cfg["selected_tastes"],
        used_weights=used_weights,
        recipe=recipe,
        process_row=process_row,
        taste_row=taste_row,
    )

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    file_stem = f"{slugify(label)}_rank{selected_rank}_{ts}"

    render_section_head("Exports", "download")
    c1, c2 = st.columns(2)
    c1.download_button(
        "Download CSV",
        data=csv_bytes,
        file_name=f"{file_stem}.csv",
        mime="text/csv",
        key=f"{key_prefix}_csv",
        use_container_width=True,
    )

    if pdf_bytes is not None:
        c2.download_button(
            "Download PDF",
            data=pdf_bytes,
            file_name=f"{file_stem}.pdf",
            mime="application/pdf",
            key=f"{key_prefix}_pdf",
            use_container_width=True,
        )
    else:
        c2.caption("PDF export unavailable (`reportlab` not installed).")

    rank_state_key = f"{key_prefix}_active_rank"
    run_id_key = f"{key_prefix}_run_id"
    if st.session_state.get(rank_state_key) != selected_idx or run_id_key not in st.session_state:
        st.session_state[rank_state_key] = selected_idx
        st.session_state[run_id_key] = f"{slugify(label)}_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}"
    run_id = st.session_state[run_id_key]

    render_section_head("Experiment Tracking & Feedback", "history")
    st.caption(f"Active Run ID: `{run_id}`")
    track_c1, track_c2 = st.columns(2)

    with track_c1:
        if st.button("Save Experiment Run", key=f"{key_prefix}_save_run", use_container_width=True):
            append_row_to_csv(
                EXPERIMENT_LOG_PATH,
                {
                    "Timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "RunID": run_id,
                    "Label": label,
                    "SelectedRank": selected_rank,
                    "Preset": cfg.get("preset", "Custom"),
                    "SelectedTastes": "|".join(cfg["selected_tastes"]),
                    "WeightJSON": to_json_text(used_weights),
                    "ConstraintJSON": to_json_text(cfg.get("constraints", {})),
                    "SearchCandidates": cfg["n_candidates"],
                    "NonSelectedPenalty": cfg["non_selected_penalty"],
                    "DistanceWeight": cfg["distance_weight"],
                    "RandomState": cfg["random_state"],
                    "Objective": float(recipe.iloc[0]["Objective"]),
                    "SelectedTasteScore": float(recipe.iloc[0]["SelectedTasteScore"]),
                    "RecipeJSON": to_json_text({c: float(recipe.iloc[0][c]) for c in recipe.columns}),
                    "ProcessJSON": to_json_text({c: float(process_row.iloc[0][c]) for c in process_row.columns}),
                    "TasteJSON": to_json_text({c: float(taste_row.iloc[0][c]) for c in taste_row.columns}),
                    "ConfidenceIndexPct": float(confidence["ConfidenceIndexPct"]),
                    "UncertaintyStd": float(unc_std) if not np.isnan(unc_std) else np.nan,
                },
            )
            st.success("Experiment saved to tracker.")

    with track_c2:
        rating = st.slider("Taste-match rating", 1, 5, 3, key=f"{key_prefix}_rating")
        feedback = st.text_input("Brew notes (optional)", key=f"{key_prefix}_feedback")
        if st.button("Submit Brew Feedback", key=f"{key_prefix}_save_feedback", use_container_width=True):
            append_row_to_csv(
                FEEDBACK_LOG_PATH,
                {
                    "Timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "RunID": run_id,
                    "Label": label,
                    "SelectedRank": selected_rank,
                    "Rating": int(rating),
                    "Feedback": feedback,
                },
            )
            st.success("Feedback submitted.")

    return {
        "recipe": recipe,
        "process_row": process_row,
        "taste_row": taste_row,
        "used_weights": used_weights,
        "export_df": export_df,
    }


def render_quality_tracking_page(assets):
    default_alg = "RandomForest"
    if st.session_state.get("single_last_result"):
        default_alg = st.session_state["single_last_result"]["cfg"].get("algorithm", default_alg)
    elif st.session_state.get("compare_last_result"):
        default_alg = st.session_state["compare_last_result"]["cfg_a"].get("algorithm", default_alg)
    elif assets.get("algorithm"):
        default_alg = assets.get("algorithm", default_alg)

    if default_alg not in MODEL_ALGORITHMS:
        default_alg = MODEL_ALGORITHMS[0]

    selected_quality_algorithm = st.selectbox(
        "Quality metrics algorithm",
        options=MODEL_ALGORITHMS,
        index=MODEL_ALGORITHMS.index(default_alg),
        key="quality_algorithm_selector",
    )

    quality_assets = assets
    if assets.get("algorithm") != selected_quality_algorithm:
        quality_assets = load_and_train_models(DATA_PATH, algorithm=selected_quality_algorithm)

    quality = quality_assets["quality"]
    cls_df = quality["classification"].copy()
    reg_df = quality["regression"].copy()
    summary = quality["summary"]

    exp_df = load_log_csv(EXPERIMENT_LOG_PATH)
    fb_df = load_log_csv(FEEDBACK_LOG_PATH)

    if not exp_df.empty:
        exp_df = exp_df.copy()
        exp_df["Timestamp"] = pd.to_datetime(exp_df["Timestamp"], errors="coerce")
        exp_df = exp_df.sort_values("Timestamp", ascending=False)
    if not fb_df.empty:
        fb_df = fb_df.copy()
        fb_df["Timestamp"] = pd.to_datetime(fb_df["Timestamp"], errors="coerce")
        fb_df = fb_df.sort_values("Timestamp", ascending=False)

    def fmt_metric(value, digits=3, suffix=""):
        return f"{value:.{digits}f}{suffix}" if pd.notna(value) else "n/a"

    mean_objective = np.nan
    if not exp_df.empty and "Objective" in exp_df.columns:
        mean_objective = pd.to_numeric(exp_df["Objective"], errors="coerce").mean()

    avg_rating = np.nan
    if not fb_df.empty and "Rating" in fb_df.columns:
        avg_rating = pd.to_numeric(fb_df["Rating"], errors="coerce").mean()

    render_section_head("Quality Snapshot", "monitoring")
    st.caption(f"Focused quality view for algorithm: {selected_quality_algorithm}")

    q1, q2, q3, q4 = st.columns(4)
    q1.metric("Macro AUC", fmt_metric(summary.get("MacroAUC", np.nan)))
    q2.metric("Macro F1", fmt_metric(summary.get("MacroF1", np.nan)))
    q3.metric("Mean Brier", fmt_metric(summary.get("MeanBrier", np.nan)))
    q4.metric("Mean ECE", fmt_metric(summary.get("MeanECE", np.nan)))

    q5, q6, q7, q8 = st.columns(4)
    q5.metric("Mean RMSE", fmt_metric(summary.get("MeanRMSE", np.nan)))
    q6.metric("Mean R2", fmt_metric(summary.get("MeanR2", np.nan)))
    q7.metric("Saved Runs", f"{len(exp_df):,}")
    q8.metric("Avg Feedback", fmt_metric(avg_rating, digits=2, suffix="/5"))

    st.caption(
        "Detailed tables and logs are available below. "
        + ("SHAP enabled." if SHAP_AVAILABLE else "SHAP unavailable in this environment; using local approximation for explanations.")
    )

    with st.expander("Detailed model metrics and charts", expanded=False):
        render_section_head("Taste Classification Metrics", "analytics")
        st.dataframe(cls_df.round(6), use_container_width=True, hide_index=True)
        if not cls_df.empty:
            st.bar_chart(cls_df.set_index("Taste")[["AUC", "F1"]])

        render_section_head("Process Regression Metrics", "query_stats")
        st.dataframe(reg_df.round(6), use_container_width=True, hide_index=True)
        if not reg_df.empty:
            st.bar_chart(reg_df.set_index("ProcessMetric")[["RMSE", "MAE"]])

    with st.expander("Detailed experiment and feedback logs", expanded=False):
        render_section_head("Experiment Tracker", "history")
        if exp_df.empty:
            st.info("No experiment runs saved yet.")
        else:
            t1, t2, t3 = st.columns(3)
            t1.metric("Unique Run IDs", f"{exp_df['RunID'].nunique():,}" if "RunID" in exp_df.columns else "n/a")
            t2.metric("Mean Objective", fmt_metric(mean_objective, digits=4))
            t3.metric("Latest Run", exp_df["Timestamp"].iloc[0].strftime("%Y-%m-%d %H:%M") if "Timestamp" in exp_df.columns and pd.notna(exp_df["Timestamp"].iloc[0]) else "n/a")

            if "Timestamp" in exp_df.columns and "Objective" in exp_df.columns:
                chart_df = exp_df.dropna(subset=["Timestamp"]).sort_values("Timestamp").set_index("Timestamp")
                if not chart_df.empty:
                    st.line_chart(chart_df[["Objective"]])

            st.dataframe(exp_df.head(200), use_container_width=True, hide_index=True)
            st.download_button(
                "Download Experiment Log CSV",
                data=exp_df.to_csv(index=False).encode("utf-8"),
                file_name="experiment_log.csv",
                mime="text/csv",
                key="quality_exp_csv",
                use_container_width=True,
            )

        render_section_head("Feedback Loop Records", "forum")
        if fb_df.empty:
            st.info("No feedback submitted yet.")
        else:
            f1, f2 = st.columns(2)
            f1.metric("Feedback Entries", f"{len(fb_df):,}")
            f2.metric("Average Rating", fmt_metric(avg_rating, digits=2, suffix="/5"))

            st.dataframe(fb_df.head(200), use_container_width=True, hide_index=True)
            st.download_button(
                "Download Feedback CSV",
                data=fb_df.to_csv(index=False).encode("utf-8"),
                file_name="feedback_log.csv",
                mime="text/csv",
                key="quality_fb_csv",
                use_container_width=True,
            )


def main():
    st.set_page_config(page_title="Coffee Recipe Recommender", page_icon=":coffee:", layout="wide")
    inject_dashboard_css()
    render_home_banner()
    render_top_menu(active="home")
    render_project_narrative()

    try:
        assets = load_and_train_models(DATA_PATH)
    except FileNotFoundError:
        st.error(f"Could not find dataset: {DATA_PATH}")
        st.stop()

    k1, k2, k3, k4 = st.columns(4)
    with k1:
        render_kpi_card("Dataset Rows", f"{len(assets['df']):,}", "Rows used after NA filtering")
    with k2:
        render_kpi_card("Taste Targets", str(len(TASTE_COLS)), "Binary taste indicators")
    with k3:
        render_kpi_card("Controllable Inputs", str(len(CONTROLLABLE_COLS)), "Inputs optimized for each recipe")
    with k4:
        render_kpi_card("Explainability", "SHAP" if SHAP_AVAILABLE else "Approx", "Local SHAP-style recipe explanations")

    tab_single, tab_compare, tab_quality, tab_about, tab_proponents = st.tabs(
        ["Single Recipe", "Compare Two Recipes", "Quality Snapshot", "About This Project", "Proponents"]
    )

    if "single_last_result" not in st.session_state:
        st.session_state["single_last_result"] = None
    if "compare_last_result" not in st.session_state:
        st.session_state["compare_last_result"] = None

    with tab_single:
        render_tab_banner(
            "Recipe Studio",
            "Select taste priorities and generate optimized recipes with constraints and confidence.",
            "local_cafe",
        )
        col_left, col_right = st.columns([0.95, 1.55], gap="large")

        with col_left:
            render_section_head("Control Panel", "tune")
            with st.container():
                cfg = collect_optimizer_controls(prefix="single", assets=assets, defaults=["Sweet"])
                run_single = st.button("Generate Recipe", type="primary", use_container_width=True, key="single_run")

        with col_right:
            render_section_head("Recipe Dashboard", "dashboard")
            if run_single:
                try:
                    out = run_optimization(cfg, assets)
                    st.session_state["single_last_result"] = {"cfg": cfg, "out": out}
                except Exception as exc:
                    st.error(f"Input error: {exc}")
                    st.session_state["single_last_result"] = None

            cached_single = st.session_state.get("single_last_result")
            if cached_single is None:
                st.info("Choose taste profiles and click **Generate Recipe**.")
            else:
                render_recipe_output(
                    "Single Recipe",
                    cached_single["cfg"],
                    cached_single["out"],
                    key_prefix="single_out",
                    assets=assets,
                )

    with tab_compare:
        render_tab_banner(
            "Comparison Lab",
            "Benchmark two preference sets side by side and inspect recipe trade-offs.",
            "balance",
        )
        render_section_head("Comparison Control Panels", "compare_arrows")
        left, right = st.columns(2, gap="large")

        with left:
            st.markdown("#### Recipe A Inputs")
            with st.container():
                cfg_a = collect_optimizer_controls(prefix="cmp_a", assets=assets, defaults=["Sweet"])

        with right:
            st.markdown("#### Recipe B Inputs")
            with st.container():
                cfg_b = collect_optimizer_controls(prefix="cmp_b", assets=assets, defaults=["Caramel"])

        run_compare = st.button("Compare Recipes", type="primary", use_container_width=True, key="compare_run")

        if run_compare:
            try:
                out_a = run_optimization(cfg_a, assets)
                out_b = run_optimization(cfg_b, assets)
                st.session_state["compare_last_result"] = {
                    "cfg_a": cfg_a,
                    "cfg_b": cfg_b,
                    "out_a": out_a,
                    "out_b": out_b,
                }
            except Exception as exc:
                st.error(f"Input error: {exc}")
                st.session_state["compare_last_result"] = None

        cached_compare = st.session_state.get("compare_last_result")
        if cached_compare is None:
            st.info("Set inputs for both sides and click **Compare Recipes**.")
        else:
            out_col_a, out_col_b = st.columns(2, gap="large")
            with out_col_a:
                r_a = render_recipe_output(
                    "Recipe A",
                    cached_compare["cfg_a"],
                    cached_compare["out_a"],
                    key_prefix="cmp_a_out",
                    assets=assets,
                )
            with out_col_b:
                r_b = render_recipe_output(
                    "Recipe B",
                    cached_compare["cfg_b"],
                    cached_compare["out_b"],
                    key_prefix="cmp_b_out",
                    assets=assets,
                )

            render_section_head("Comparison Summary", "summarize")
            obj_a = float(r_a["recipe"].iloc[0]["Objective"])
            obj_b = float(r_b["recipe"].iloc[0]["Objective"])
            score_a = float(r_a["recipe"].iloc[0]["SelectedTasteScore"])
            score_b = float(r_b["recipe"].iloc[0]["SelectedTasteScore"])
            cm1, cm2, cm3 = st.columns(3)
            cm1.metric("Objective Delta (B-A)", f"{obj_b - obj_a:+.4f}")
            cm2.metric("Recipe A Score", f"{score_a:.4f}")
            cm3.metric("Recipe B Score", f"{score_b:.4f}")

            comp_rows = []
            for c in CONTROLLABLE_COLS:
                a_val = float(r_a["recipe"].iloc[0][c])
                b_val = float(r_b["recipe"].iloc[0][c])
                comp_rows.append({"Metric": c, "Recipe A": a_val, "Recipe B": b_val, "Delta (B-A)": b_val - a_val})

            for c in PROCESS_COLS:
                a_val = float(r_a["process_row"].iloc[0][c])
                b_val = float(r_b["process_row"].iloc[0][c])
                comp_rows.append({"Metric": c, "Recipe A": a_val, "Recipe B": b_val, "Delta (B-A)": b_val - a_val})

            selected_union = sorted(
                set(cached_compare["cfg_a"]["selected_tastes"]) | set(cached_compare["cfg_b"]["selected_tastes"])
            )
            for t in selected_union:
                a_val = float(r_a["taste_row"].iloc[0][t])
                b_val = float(r_b["taste_row"].iloc[0][t])
                comp_rows.append(
                    {
                        "Metric": f"TasteProb::{t}",
                        "Recipe A": a_val,
                        "Recipe B": b_val,
                        "Delta (B-A)": b_val - a_val,
                    }
                )

            comp_df = pd.DataFrame(comp_rows)
            st.dataframe(comp_df.round(6), use_container_width=True, hide_index=True)

            compare_export_df = pd.concat([r_a["export_df"], r_b["export_df"]], ignore_index=True)
            compare_csv = export_csv_bytes(compare_export_df)
            compare_pdf = build_compare_pdf_bytes("Recipe A", r_a["export_df"], "Recipe B", r_b["export_df"])
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")

            c1, c2 = st.columns(2)
            c1.download_button(
                "Download Comparison CSV",
                data=compare_csv,
                file_name=f"recipe_comparison_{ts}.csv",
                mime="text/csv",
                key="cmp_export_csv",
                use_container_width=True,
            )

            if compare_pdf is not None:
                c2.download_button(
                    "Download Comparison PDF",
                    data=compare_pdf,
                    file_name=f"recipe_comparison_{ts}.pdf",
                    mime="application/pdf",
                    key="cmp_export_pdf",
                    use_container_width=True,
                )
            else:
                c2.caption("Comparison PDF unavailable (`reportlab` not installed).")

    with tab_quality:
        render_tab_banner(
            "Quality Snapshot",
            "See the key model KPIs first, then open detailed diagnostics only when needed.",
            "monitoring",
        )
        render_quality_tracking_page(assets)

    with tab_about:
        render_tab_banner(
            "Project Story",
            "Understand the business case and strategic value behind the recommendation engine.",
            "menu_book",
        )
        render_about_project_page()

    with tab_proponents:
        render_tab_banner(
            "Proponents",
            "Meet the team building this data-driven coffee personalization platform.",
            "groups",
        )
        render_proponents_page()

    st.divider()
    st.caption(
        "Model type: selectable two-stage ML pipeline (RandomForest, GradientBoosting, XGBoost, NeuralNetwork). "
        "This is a decision-support prototype and should be validated with real brews/tastings."
    )


if __name__ == "__main__":
    main()
