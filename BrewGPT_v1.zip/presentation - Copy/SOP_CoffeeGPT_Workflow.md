# SOP: CoffeeGPT Two-Stage Recipe Recommendation and Model Comparison

## Document Control
- SOP ID: `CGPT-ML-SOP-001`
- Version: `1.0`
- Effective Date: `March 15, 2026`
- System: `CoffeeGPT Streamlit Web App`
- Related Files: `app.py`, `app_model_comparison.py`, `pages/Model_Comparison.py`

## 1. Purpose
Define the standard operating procedure for generating optimized coffee recipes from selected taste targets, comparing algorithms, and presenting final recommendations with traceable model metrics.

## 2. Scope
This SOP applies to:
- Home page (`app.py`) single-recipe and two-recipe workflows
- Model Comparison page (`app_model_comparison.py`) multi-algorithm comparison
- Quality Snapshot monitoring, experiment logs, and feedback logs

This SOP covers the full ML pipeline from data preparation to final recommendation display.

## 3. Responsibilities
- Project Owner: approves objective priorities and final recommendation policy.
- ML Engineer: maintains model pipeline, tuning logic, and metric definitions.
- App Engineer: maintains Streamlit UI, HTML tables, and user flow.
- QA/Reviewer: validates outputs, metric consistency, and acceptance criteria.

## 4. Procedure

### 4.1 Input Definition
1. User selects one or more target taste profiles.
2. User assigns priority weights to selected tastes.
3. User sets optimization constraints and penalties:
- Candidate count
- Non-selected taste penalty
- Distance penalty
- Recipe bounds for controllable settings

### 4.2 Data Preparation
1. Load source dataset.
2. Keep required columns:
- Controllable inputs: `Volume`, `Brew Temperature`, `Pour Temp`, `Dose`, `Grind`
- Process outcomes (stage-1 targets)
- Taste binary targets (stage-2 targets)
3. Drop rows with missing values in required fields.

### 4.3 Two-Stage Modeling
1. Train Stage 1 regressor(s): controllables -> process outcomes.
2. Train Stage 2 classifier(s): controllables + process outcomes -> taste probabilities.

Algorithm mapping used:
- `RandomForest`: `RandomForestRegressor` -> `RandomForestClassifier`
- `GradientBoosting`: `RandomForestRegressor` -> `GradientBoostingClassifier` (current implementation)
- `XGBoost`: `XGBRegressor` -> `XGBClassifier`
- `NeuralNetwork`: `MLPRegressor` -> `MLPClassifier`

### 4.4 Hyperparameter Tuning (Optional)
1. Run per-algorithm tuning where enabled.
2. Select candidate with best tuning objective:
- `tune_score = Val_SelectedMacroAUC - 0.05 * Val_MeanRMSE`
3. Save best configuration for downstream optimization.

### 4.5 Recipe Optimization
1. Generate feasible candidate recipes inside user constraints.
2. Predict process outcomes using Stage 1.
3. Predict taste probabilities using Stage 2.
4. Score each candidate:
- `final_score = weighted_selected_tastes - non_selected_penalty - distance_penalty`
5. Rank candidates and keep top-k.
6. Select top-ranked candidate as algorithm-level best recipe.

### 4.6 Model Comparison (4 Algorithms)
1. Run the same user selection across all four algorithms.
2. Build comparison tables for:
- Recommended outputs
- Objective scores
- Selection-specific metrics (`SelectedMacroAUC`, `SelectedMacroAP`, `SelectedMacroF1`, `SelectedMeanBrier`, `SelectedMeanECE`)
3. Determine overall BEST algorithm by selected priority mode:
- `AUC-first`: sort by `SelectedMacroAUC`, then `Objective_Final`, then `SelectedMacroF1`
- `recipe-objective-first`: sort by `Objective_Final`, then `SelectedMacroAUC`, then `SelectedMacroF1`
4. Highlight top row as BEST.

### 4.7 Recommendation Presentation
Display recommendation in explicit format:
- `Taste Profile selected -> ...`
- `Derived from Algorithm -> ...`
- `Output -> Volume, Brew Temperature, Pour Temp, Dose, Grind`

Also present the recommendation in HTML table format for easier comparison.

### 4.8 Explainability
1. Generate SHAP-based factor contributions per algorithm and taste target where available.
2. Use local approximation fallback if SHAP is unavailable.
3. Present contributions as sortable tables and charts.

### 4.9 Quality Snapshot and Tracking
1. Show compact KPI-first metrics for selected algorithm:
- `Macro AUC`, `Macro F1`, `Mean Brier`, `Mean ECE`, `Mean RMSE`, `Mean R2`
2. Expose detailed tables/charts and logs via expanders.
3. Persist experiment runs and user feedback in CSV logs.

## 5. Acceptance Criteria

### 5.1 Functional
- User can select tastes and weights and generate at least one recipe.
- User can switch algorithm and obtain corresponding outputs.
- Model Comparison shows all four algorithms in one table.
- BEST algorithm is highlighted and recommendation row is visible.

### 5.2 Metric Integrity
- Selection-specific metrics are computed for each algorithm.
- Ranking follows selected priority mode exactly.
- Quality Snapshot values correspond to currently selected algorithm.

### 5.3 UX/Presentation
- Long HTML tables are scrollable horizontally/vertically.
- Banner and page navigation are consistent across Home and Model Comparison.
- Recommended settings are shown in both narrative and table format.

### 5.4 Technical Validation
- Python syntax check passes:
  - `python -m py_compile app.py app_model_comparison.py pages\\Model_Comparison.py`
- App starts without runtime import errors in configured environment.

## 6. Records and Outputs
- Experiment log CSV
- Feedback log CSV
- Downloadable recipe and comparison exports (CSV/PDF where available)
- On-screen HTML comparison and recommendation tables

## 7. Revision Policy
- Update SOP version whenever ranking logic, objective function, or algorithm mapping changes.
- Re-run acceptance criteria after every material pipeline/UI update.
