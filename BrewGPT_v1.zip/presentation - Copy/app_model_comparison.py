import time
import itertools
import warnings

import numpy as np
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    roc_auc_score,
    average_precision_score,
    brier_score_loss,
    f1_score,
    mean_absolute_error,
    mean_squared_error,
    r2_score,
)
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier, GradientBoostingClassifier
from sklearn.neural_network import MLPRegressor, MLPClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.neighbors import NearestNeighbors

import shap

try:
    from xgboost import XGBRegressor, XGBClassifier

    XGBOOST_AVAILABLE = True
except Exception:
    XGBOOST_AVAILABLE = False


warnings.filterwarnings("ignore")
sns.set_theme(style="whitegrid")

DATA_PATH = "cotter_dataset.csv"
RANDOM_STATE = 42

TASTE_COLS = [
    "Tea.floral",
    "Fruit",
    "Citrus",
    "Green.veg",
    "Paper.wood",
    "Burnt",
    "Cereal",
    "Nutty",
    "Dark.chocolate",
    "Caramel",
    "Bitter",
    "Astringent",
    "Roasted",
    "Sour",
    "Thick.viscous",
    "Sweet",
    "Rubber",
]
CONTROLLABLE_COLS = ["Volume", "Brew Temperature", "Pour Temp", "Dose", "Grind"]
PROCESS_COLS = ["90Sec Temp", "Brew Mass", "TDS__1", "Percent Extraction"]


def render_top_menu(active: str = "comparison"):
    st.markdown(
        """
        <style>
            .top-menu-shell {
                margin: 2px 0 10px 0;
                padding: 9px 12px;
                border-radius: 12px;
                border: 1px solid #ddc6aa;
                background: rgba(255, 248, 237, 0.9);
                box-shadow: 0 3px 10px rgba(72, 52, 39, 0.08);
            }
            .top-menu-title {
                margin: 0;
                font-size: 0.82rem;
                letter-spacing: 0.06em;
                text-transform: uppercase;
                color: #7e614f;
                font-weight: 800;
            }
            div[data-testid="stPageLink"] a {
                border: 1px solid #cba780;
                border-radius: 999px;
                background: #f8ebda;
                color: #4b3329 !important;
                font-weight: 700;
                padding: 0.42rem 0.95rem;
                transition: all 0.15s ease;
            }
            div[data-testid="stPageLink"] a:hover {
                background: #f4dfc3;
                border-color: #b67a3c;
                transform: translateY(-1px);
            }
        </style>
        <div class="top-menu-shell">
            <p class="top-menu-title">Page Navigator</p>
        </div>
        """,
        unsafe_allow_html=True,
    )
    c1, c2, _ = st.columns([1.3, 2.1, 6.6])
    if hasattr(st, "page_link"):
        with c1:
            st.page_link("app.py", label="Home", use_container_width=True)
        with c2:
            st.page_link("pages/Model_Comparison.py", label="Model Comparison", use_container_width=True)
    else:
        st.markdown("[Home](./) | [Model Comparison](./Model_Comparison)")
    st.caption(f"Current Page: {'Home' if active == 'home' else 'Model Comparison'}")
    st.markdown("---")


def render_scrollable_html_table(table_html: str, max_height: int = 440):
    html = (
        "<div style='"
        "overflow-x:auto;"
        "overflow-y:auto;"
        f"max-height:{max_height}px;"
        "border:1px solid #e2d4c3;"
        "border-radius:10px;"
        "padding:4px;"
        "background:#fffaf4;"
        "box-shadow: inset 0 1px 3px rgba(0,0,0,0.06);"
        "'>"
        f"{table_html}"
        "</div>"
    )
    st.markdown(html, unsafe_allow_html=True)


def render_home_banner():
    st.markdown(
        """
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Baloo+2:wght@700;800&family=Playfair+Display:wght@600;700;800&family=Manrope:wght@400;500;600;700;800&display=swap');
            :root {
                --font-display: "Playfair Display", Georgia, serif;
                --font-body: "Manrope", "Segoe UI", sans-serif;
                --font-fun: "Baloo 2", "Manrope", sans-serif;
            }
            html, body, [data-testid="stAppViewContainer"], [data-testid="stMarkdownContainer"] {
                font-family: var(--font-body);
            }
            .hero-banner {
                margin: 4px 0 14px 0;
                padding: 22px 22px;
                border-radius: 18px;
                border: 1px solid #3f1f0f;
                background: linear-gradient(120deg, #2a0f05 0%, #3a1407 52%, #231008 100%);
                box-shadow: 0 10px 24px rgba(30, 13, 6, 0.32);
                position: relative;
                overflow: hidden;
            }
            .hero-banner::after {
                content: "";
                position: absolute;
                right: -38px;
                top: -38px;
                width: 140px;
                height: 140px;
                border-radius: 999px;
                background: radial-gradient(circle, rgba(222,154,99,0.28) 0%, rgba(222,154,99,0.04) 70%);
            }
            .hero-title {
                margin: 0;
                font-family: var(--font-fun);
                font-size: 4.2rem;
                line-height: 0.96;
                letter-spacing: 0.015em;
                position: relative;
                z-index: 1;
                font-weight: 800;
            }
            @media (max-width: 820px) {
                .hero-title {
                    font-size: 3.15rem;
                }
            }
            .hero-word-coffee {
                color: #de9a63;
                text-shadow:
                    0 3px 0 #8a4f2a,
                    0 8px 18px rgba(88, 56, 37, 0.36);
            }
            .hero-word-gpt {
                color: #fff6ea;
                margin-left: 0.18rem;
                text-shadow:
                    0 3px 0 #6a655f,
                    0 8px 18px rgba(70, 58, 49, 0.30);
            }
            .hero-sub {
                margin: 6px 0 0 0;
                font-size: 1.08rem;
                color: #fff6ea;
                font-weight: 800;
                position: relative;
                z-index: 1;
            }
            .hero-team {
                margin: 7px 0 0 0;
                font-size: 0.98rem;
                color: #fff6ea;
                font-weight: 700;
                letter-spacing: 0.015em;
                position: relative;
                z-index: 1;
            }
        </style>
        <div class="hero-banner">
            <h1 class="hero-title">
                <span class="hero-word-coffee">Brew</span><span class="hero-word-gpt">GPT</span>
            </h1>
            <p class="hero-sub">A Machine Learning Project</p>
            <p class="hero-team">Altonaga- Sarceda- Sunga - Torres</p>
        </div>
        """,
        unsafe_allow_html=True,
    )


def normalize_weights(selected_tastes, raw_weights):
    s = pd.Series({t: float(raw_weights.get(t, 0.0)) for t in selected_tastes}, index=selected_tastes)
    if (s < 0).any() or float(s.sum()) <= 0:
        raise ValueError("Taste weights must be non-negative and sum to > 0.")
    return s / s.sum()


def expected_calibration_error(y_true, y_prob, n_bins=10):
    y_true = np.asarray(y_true, dtype=float)
    y_prob = np.asarray(y_prob, dtype=float)
    if y_true.size == 0:
        return np.nan

    bins = np.linspace(0.0, 1.0, n_bins + 1)
    binned = np.digitize(y_prob, bins, right=True) - 1
    binned = np.clip(binned, 0, n_bins - 1)

    ece = 0.0
    for i in range(n_bins):
        mask = binned == i
        if not mask.any():
            continue
        confidence = y_prob[mask].mean()
        accuracy = y_true[mask].mean()
        ece += np.abs(confidence - accuracy) * (mask.sum() / y_true.size)
    return float(ece)


def positive_proba(model, x):
    if not hasattr(model, "predict_proba"):
        pred = np.asarray(model.predict(x)).reshape(-1)
        return np.clip(pred, 0.0, 1.0)

    proba = np.asarray(model.predict_proba(x))
    if proba.ndim == 1:
        return np.clip(proba, 0.0, 1.0)

    classes = getattr(model, "classes_", None)
    if proba.shape[1] == 1:
        if classes is not None and len(classes) == 1 and int(classes[0]) == 1:
            return np.ones(proba.shape[0], dtype=float)
        return np.zeros(proba.shape[0], dtype=float)

    if classes is not None:
        idx = np.where(np.asarray(classes) == 1)[0]
        if idx.size > 0:
            return proba[:, int(idx[0])]
    return proba[:, 1]


@st.cache_data(show_spinner=False)
def load_data(path):
    required_cols = sorted(set(CONTROLLABLE_COLS + PROCESS_COLS + TASTE_COLS))
    raw_df = pd.read_csv(path)
    df = raw_df[required_cols].dropna().copy()
    for t in TASTE_COLS:
        df[t] = df[t].astype(int)
    return df


def dict_grid_to_list(grid):
    keys = list(grid.keys())
    vals = [grid[k] for k in keys]
    rows = []
    for combo in itertools.product(*vals):
        rows.append({k: v for k, v in zip(keys, combo)})
    return rows


def build_stage1_model(algorithm, seed, params):
    params = params or {}
    if algorithm in ("RandomForest", "GradientBoosting"):
        return RandomForestRegressor(
            n_estimators=int(params.get("n_estimators", 220)),
            max_depth=int(params.get("max_depth", 12)),
            min_samples_leaf=int(params.get("min_samples_leaf", 2)),
            random_state=seed,
            n_jobs=1,
        )
    if algorithm == "XGBoost":
        return XGBRegressor(
            n_estimators=int(params.get("n_estimators", 260)),
            max_depth=int(params.get("max_depth", 4)),
            learning_rate=float(params.get("learning_rate", 0.05)),
            subsample=float(params.get("subsample", 0.9)),
            colsample_bytree=float(params.get("colsample_bytree", 0.9)),
            objective="reg:squarederror",
            random_state=seed,
            n_jobs=1,
        )
    h = params.get("hidden_layer_sizes", (64, 32))
    return Pipeline(
        [
            ("scaler", StandardScaler()),
            (
                "mlp",
                MLPRegressor(
                    hidden_layer_sizes=h,
                    alpha=float(params.get("alpha", 1e-4)),
                    learning_rate_init=float(params.get("learning_rate_init", 1e-3)),
                    activation="relu",
                    max_iter=int(params.get("max_iter", 450)),
                    early_stopping=True,
                    random_state=seed,
                ),
            ),
        ]
    )


def build_stage2_model(algorithm, seed, params):
    params = params or {}
    if algorithm == "RandomForest":
        return RandomForestClassifier(
            n_estimators=int(params.get("n_estimators", 180)),
            max_depth=int(params.get("max_depth", 10)),
            min_samples_leaf=int(params.get("min_samples_leaf", 2)),
            class_weight="balanced_subsample",
            random_state=seed,
            n_jobs=1,
        )
    if algorithm == "GradientBoosting":
        return GradientBoostingClassifier(
            n_estimators=int(params.get("n_estimators", 220)),
            learning_rate=float(params.get("learning_rate", 0.05)),
            max_depth=int(params.get("max_depth", 2)),
            subsample=float(params.get("subsample", 0.85)),
            random_state=seed,
        )
    if algorithm == "XGBoost":
        return XGBClassifier(
            n_estimators=int(params.get("n_estimators", 260)),
            max_depth=int(params.get("max_depth", 4)),
            learning_rate=float(params.get("learning_rate", 0.05)),
            subsample=float(params.get("subsample", 0.9)),
            colsample_bytree=float(params.get("colsample_bytree", 0.9)),
            objective="binary:logistic",
            eval_metric="logloss",
            random_state=seed,
            n_jobs=1,
        )
    h = params.get("hidden_layer_sizes", (64, 32))
    return Pipeline(
        [
            ("scaler", StandardScaler()),
            (
                "mlp",
                MLPClassifier(
                    hidden_layer_sizes=h,
                    alpha=float(params.get("alpha", 1e-4)),
                    learning_rate_init=float(params.get("learning_rate_init", 1e-3)),
                    activation="relu",
                    max_iter=int(params.get("max_iter", 450)),
                    early_stopping=True,
                    random_state=seed,
                ),
            ),
        ]
    )


def fit_two_stage_models(train_df, algorithm, random_state, stage1_params, stage2_params, stage2_targets):
    stage1 = {}
    for i, pcol in enumerate(PROCESS_COLS):
        reg = build_stage1_model(algorithm, random_state + 100 + i, stage1_params)
        reg.fit(train_df[CONTROLLABLE_COLS], train_df[pcol])
        stage1[pcol] = reg

    stage2 = {}
    x2 = train_df[CONTROLLABLE_COLS + PROCESS_COLS]
    targets = stage2_targets if stage2_targets is not None else TASTE_COLS
    for j, tcol in enumerate(targets):
        clf = build_stage2_model(algorithm, random_state + 200 + j, stage2_params)
        clf.fit(x2, train_df[tcol].astype(int))
        stage2[tcol] = clf
    return stage1, stage2


def predict_two_stage(candidates, stage1, stage2):
    process_pred = pd.DataFrame(index=candidates.index)
    for pcol in PROCESS_COLS:
        process_pred[pcol] = stage1[pcol].predict(candidates[CONTROLLABLE_COLS])
    x2 = pd.concat([candidates[CONTROLLABLE_COLS], process_pred[PROCESS_COLS]], axis=1)
    taste_prob = pd.DataFrame(index=candidates.index)
    for tcol in TASTE_COLS:
        taste_prob[tcol] = positive_proba(stage2[tcol], x2)
    return process_pred, taste_prob


def evaluate_pipeline(train_df, test_df, algorithm, tuned_params):
    t0 = time.time()
    stage1, stage2 = fit_two_stage_models(
        train_df,
        algorithm,
        random_state=RANDOM_STATE,
        stage1_params=tuned_params.get("stage1", {}),
        stage2_params=tuned_params.get("stage2", {}),
        stage2_targets=TASTE_COLS,
    )
    train_seconds = time.time() - t0

    process_pred_test = pd.DataFrame(index=test_df.index)
    reg_rows = []
    for pcol in PROCESS_COLS:
        y_true = test_df[pcol].values
        y_pred = stage1[pcol].predict(test_df[CONTROLLABLE_COLS])
        process_pred_test[pcol] = y_pred
        reg_rows.append(
            {
                "ProcessMetric": pcol,
                "MAE": float(mean_absolute_error(y_true, y_pred)),
                "RMSE": float(np.sqrt(mean_squared_error(y_true, y_pred))),
                "R2": float(r2_score(y_true, y_pred)),
            }
        )

    x2_test = pd.concat([test_df[CONTROLLABLE_COLS], process_pred_test[PROCESS_COLS]], axis=1)
    cls_rows = []
    for tcol in TASTE_COLS:
        y_true = test_df[tcol].astype(int).values
        y_prob = positive_proba(stage2[tcol], x2_test)
        y_pred = (y_prob >= 0.5).astype(int)
        auc = np.nan
        ap = np.nan
        if np.unique(y_true).size > 1:
            auc = float(roc_auc_score(y_true, y_prob))
            ap = float(average_precision_score(y_true, y_prob))
        cls_rows.append(
            {
                "Taste": tcol,
                "AUC": auc,
                "AvgPrecision": ap,
                "F1": float(f1_score(y_true, y_pred, zero_division=0)),
                "Brier": float(brier_score_loss(y_true, y_prob)),
                "ECE_10bin": expected_calibration_error(y_true, y_prob, n_bins=10),
            }
        )

    reg_df = pd.DataFrame(reg_rows)
    cls_df = pd.DataFrame(cls_rows)
    summary = {
        "Algorithm": algorithm,
        "MeanMAE": float(np.nanmean(reg_df["MAE"])),
        "MeanRMSE": float(np.nanmean(reg_df["RMSE"])),
        "MeanR2": float(np.nanmean(reg_df["R2"])),
        "MacroAUC": float(np.nanmean(cls_df["AUC"])),
        "MacroAP": float(np.nanmean(cls_df["AvgPrecision"])),
        "MacroF1": float(np.nanmean(cls_df["F1"])),
        "MeanBrier": float(np.nanmean(cls_df["Brier"])),
        "MeanECE": float(np.nanmean(cls_df["ECE_10bin"])),
        "TrainSeconds": float(train_seconds),
    }
    return {"stage1": stage1, "stage2": stage2, "reg_df": reg_df, "cls_df": cls_df, "summary": summary}


def build_candidate_space(train_df):
    bounds = {
        "Volume": (float(train_df["Volume"].quantile(0.01)), float(train_df["Volume"].quantile(0.99))),
        "Brew Temperature": (
            float(train_df["Brew Temperature"].quantile(0.01)),
            float(train_df["Brew Temperature"].quantile(0.99)),
        ),
        "Pour Temp": (float(train_df["Pour Temp"].quantile(0.01)), float(train_df["Pour Temp"].quantile(0.99))),
    }
    allowed_dose = np.array(sorted(train_df["Dose"].unique().tolist()), dtype=float)
    allowed_grind = np.array(sorted(train_df["Grind"].astype(int).unique().tolist()), dtype=int)
    return bounds, allowed_dose, allowed_grind


def sample_candidates(n_samples, bounds, allowed_dose, allowed_grind, random_state):
    rng = np.random.default_rng(random_state)
    return pd.DataFrame(
        {
            "Volume": rng.uniform(bounds["Volume"][0], bounds["Volume"][1], n_samples),
            "Brew Temperature": rng.uniform(bounds["Brew Temperature"][0], bounds["Brew Temperature"][1], n_samples),
            "Pour Temp": rng.uniform(bounds["Pour Temp"][0], bounds["Pour Temp"][1], n_samples),
            "Dose": rng.choice(allowed_dose, n_samples, replace=True),
            "Grind": rng.choice(allowed_grind, n_samples, replace=True),
        }
    )


def score_candidates(taste_prob_df, selected_tastes, normalized_weights, non_selected_penalty):
    selected_score = np.zeros(len(taste_prob_df), dtype=float)
    for t in selected_tastes:
        selected_score += normalized_weights[t] * taste_prob_df[t].values
    others = [t for t in TASTE_COLS if t not in selected_tastes]
    other_penalty = non_selected_penalty * taste_prob_df[others].mean(axis=1).values if others else 0.0
    return selected_score - other_penalty


def optimize_recipe(train_df, stage1, stage2, selected_tastes, normalized_weights, n_candidates, non_selected_penalty, distance_weight, seed):
    bounds, allowed_dose, allowed_grind = build_candidate_space(train_df)
    cand = sample_candidates(n_candidates, bounds, allowed_dose, allowed_grind, random_state=seed)
    process_pred, taste_prob = predict_two_stage(cand, stage1, stage2)
    base_score = score_candidates(taste_prob, selected_tastes, normalized_weights, non_selected_penalty)

    scaler = StandardScaler().fit(train_df[CONTROLLABLE_COLS])
    nn = NearestNeighbors(n_neighbors=1)
    nn.fit(scaler.transform(train_df[CONTROLLABLE_COLS]))
    dists, _ = nn.kneighbors(scaler.transform(cand[CONTROLLABLE_COLS]))
    d = dists[:, 0]
    d_norm = d / (np.quantile(d, 0.90) + 1e-8)
    final_score = base_score - distance_weight * d_norm
    best_idx = int(np.argmax(final_score))
    return {
        "best_recipe": cand.iloc[best_idx].copy(),
        "best_process": process_pred.iloc[best_idx].copy(),
        "best_taste_prob": taste_prob.iloc[best_idx].copy(),
        "best_base_score": float(base_score[best_idx]),
        "best_final_score": float(final_score[best_idx]),
    }


def selected_metrics_from_cls(cls_df, selected_tastes):
    sub = cls_df[cls_df["Taste"].isin(selected_tastes)].copy()
    return {
        "SelectedMacroAUC": float(np.nanmean(sub["AUC"])),
        "SelectedMacroAP": float(np.nanmean(sub["AvgPrecision"])),
        "SelectedMacroF1": float(np.nanmean(sub["F1"])),
        "SelectedMeanBrier": float(np.nanmean(sub["Brier"])),
        "SelectedMeanECE": float(np.nanmean(sub["ECE_10bin"])),
    }


def tune_algorithm(train_base_df, val_df, algorithm, selected_tastes, n_trials):
    stage1_grids = {
        "RandomForest": {"n_estimators": [160, 220], "max_depth": [8, 12], "min_samples_leaf": [1, 2]},
        "GradientBoosting": {"n_estimators": [160, 220], "max_depth": [8, 12], "min_samples_leaf": [1, 2]},
        "XGBoost": {"n_estimators": [180, 260], "max_depth": [3, 4], "learning_rate": [0.03, 0.05], "subsample": [0.8, 0.9], "colsample_bytree": [0.8, 0.9]},
        "NeuralNetwork": {"hidden_layer_sizes": [(64, 32), (96, 48)], "alpha": [1e-4, 5e-4], "learning_rate_init": [5e-4, 1e-3], "max_iter": [400, 500]},
    }
    stage2_grids = {
        "RandomForest": {"n_estimators": [140, 180], "max_depth": [8, 10], "min_samples_leaf": [1, 2]},
        "GradientBoosting": {"n_estimators": [160, 220], "learning_rate": [0.03, 0.05], "max_depth": [2, 3], "subsample": [0.8, 1.0]},
        "XGBoost": {"n_estimators": [180, 260], "max_depth": [3, 4], "learning_rate": [0.03, 0.05], "subsample": [0.8, 0.9], "colsample_bytree": [0.8, 0.9]},
        "NeuralNetwork": {"hidden_layer_sizes": [(64, 32), (96, 48)], "alpha": [1e-4, 5e-4], "learning_rate_init": [5e-4, 1e-3], "max_iter": [400, 500]},
    }
    s1_space = dict_grid_to_list(stage1_grids[algorithm])
    s2_space = dict_grid_to_list(stage2_grids[algorithm])
    rng = np.random.default_rng(RANDOM_STATE)
    rows = []
    for i in range(n_trials):
        p1 = s1_space[int(rng.integers(0, len(s1_space)))]
        p2 = s2_space[int(rng.integers(0, len(s2_space)))]
        stage1, stage2 = fit_two_stage_models(train_base_df, algorithm, RANDOM_STATE + i, p1, p2, selected_tastes)

        proc_pred = pd.DataFrame(index=val_df.index)
        rmse_vals = []
        for p in PROCESS_COLS:
            yp = stage1[p].predict(val_df[CONTROLLABLE_COLS])
            proc_pred[p] = yp
            rmse_vals.append(np.sqrt(mean_squared_error(val_df[p].values, yp)))
        x2_val = pd.concat([val_df[CONTROLLABLE_COLS], proc_pred[PROCESS_COLS]], axis=1)
        auc_vals = []
        for t in selected_tastes:
            yt = val_df[t].astype(int).values
            yp = positive_proba(stage2[t], x2_val)
            auc_vals.append(roc_auc_score(yt, yp) if np.unique(yt).size > 1 else 0.5)

        mean_auc = float(np.nanmean(auc_vals))
        mean_rmse = float(np.nanmean(rmse_vals))
        tune_score = mean_auc - 0.05 * mean_rmse
        rows.append({"TuneScore": tune_score, "Val_SelectedMacroAUC": mean_auc, "Val_MeanRMSE": mean_rmse, "stage1": p1, "stage2": p2})
    tdf = pd.DataFrame(rows).sort_values("TuneScore", ascending=False).reset_index(drop=True)
    best = tdf.iloc[0]
    return tdf, {"stage1": best["stage1"], "stage2": best["stage2"]}


def shap_array_from_output(shap_output):
    if isinstance(shap_output, list):
        arr = np.asarray(shap_output[-1])
    elif hasattr(shap_output, "values"):
        arr = np.asarray(shap_output.values)
    else:
        arr = np.asarray(shap_output)
    if arr.ndim == 3:
        arr = arr[:, :, -1]
    return arr


def mean_abs_shap_for_model(model, algorithm, x_train_ref, x_explain, bg_size=40, ex_size=60):
    if algorithm in ("RandomForest", "GradientBoosting", "XGBoost"):
        explainer = shap.TreeExplainer(model)
        shap_raw = explainer.shap_values(x_explain)
        arr = shap_array_from_output(shap_raw)
        return np.mean(np.abs(arr), axis=0)

    bg = shap.sample(x_train_ref, min(bg_size, len(x_train_ref)), random_state=RANDOM_STATE)
    ex = x_explain.sample(min(ex_size, len(x_explain)), random_state=RANDOM_STATE)

    def f(x):
        x_df = pd.DataFrame(x, columns=x_train_ref.columns)
        return positive_proba(model, x_df)

    explainer = shap.KernelExplainer(f, bg.values)
    shap_raw = explainer.shap_values(ex.values, nsamples=100)
    arr = shap_array_from_output(shap_raw)
    return np.mean(np.abs(arr), axis=0)


def main():
    st.set_page_config(page_title="Coffee Algorithm Comparison", layout="wide")
    render_home_banner()
    render_top_menu(active="comparison")

    df = load_data(DATA_PATH)

    with st.sidebar:
        st.header("Inputs")
        selected_tastes = st.multiselect("Taste profiles", TASTE_COLS, default=["Sweet", "Caramel", "Nutty"])
        if not selected_tastes:
            st.warning("Select at least one taste.")
            return

        st.markdown("Weights")
        raw_weights = {}
        for t in selected_tastes:
            raw_weights[t] = st.slider(f"{t} weight", 1, 100, 30)

        priority_mode = st.selectbox("Recommendation priority", ["AUC-first", "recipe-objective-first"])
        n_candidates = st.slider("Candidate recipes", 2000, 20000, 12000, step=1000)
        non_selected_penalty = st.slider("Non-selected penalty", 0.0, 0.6, 0.20, step=0.01)
        distance_weight = st.slider("Distance penalty", 0.0, 0.5, 0.08, step=0.01)
        run_tuning = st.checkbox("Tune hyperparameters", value=True)
        tuning_trials = st.slider("Tuning trials / algorithm", 2, 12, 6)
        run_shap = st.checkbox("Run SHAP comparison (slower)", value=False)
        shap_max_tastes = st.slider("Max tastes for SHAP", 1, 6, 3)
        run = st.button("Run Comparison", type="primary", use_container_width=True)

    if not run:
        st.info("Set your preferences and click Run Comparison.")
        return

    normalized_weights = normalize_weights(selected_tastes, raw_weights)
    train_df, test_df = train_test_split(df, test_size=0.20, random_state=RANDOM_STATE, shuffle=True)

    algorithms = ["RandomForest", "GradientBoosting", "XGBoost", "NeuralNetwork"]
    if not XGBOOST_AVAILABLE:
        algorithms = [a for a in algorithms if a != "XGBoost"]

    tuned_param_map = {a: {"stage1": {}, "stage2": {}} for a in algorithms}
    tuning_rows = []
    if run_tuning:
        tune_train_df, tune_val_df = train_test_split(train_df, test_size=0.20, random_state=RANDOM_STATE, shuffle=True)
        with st.spinner("Tuning models..."):
            for alg in algorithms:
                tdf, best_params = tune_algorithm(tune_train_df, tune_val_df, alg, selected_tastes, tuning_trials)
                tuned_param_map[alg] = best_params
                tuning_rows.append(
                    {
                        "Algorithm": alg,
                        "TuneScore": float(tdf.iloc[0]["TuneScore"]),
                        "Val_SelectedMacroAUC": float(tdf.iloc[0]["Val_SelectedMacroAUC"]),
                        "Val_MeanRMSE": float(tdf.iloc[0]["Val_MeanRMSE"]),
                        "BestStage1Params": str(best_params["stage1"]),
                        "BestStage2Params": str(best_params["stage2"]),
                    }
                )

    results = {}
    with st.spinner("Training and evaluating algorithms..."):
        for alg in algorithms:
            results[alg] = evaluate_pipeline(train_df, test_df, alg, tuned_param_map[alg])

    pred_rows = []
    metric_rows = []
    for i, alg in enumerate(algorithms):
        opt = optimize_recipe(
            train_df,
            results[alg]["stage1"],
            results[alg]["stage2"],
            selected_tastes,
            normalized_weights,
            n_candidates,
            non_selected_penalty,
            distance_weight,
            RANDOM_STATE + i,
        )
        row = {
            "Algorithm": alg,
            "Objective_Base": opt["best_base_score"],
            "Objective_Final": opt["best_final_score"],
            **{c: float(opt["best_recipe"][c]) for c in CONTROLLABLE_COLS},
            **{f"Pred_{p}": float(opt["best_process"][p]) for p in PROCESS_COLS},
            **{f"P({t})": float(opt["best_taste_prob"][t]) for t in selected_tastes},
        }
        pred_rows.append(row)
        sel = selected_metrics_from_cls(results[alg]["cls_df"], selected_tastes)
        metric_rows.append({"Algorithm": alg, **sel, "Objective_Base": opt["best_base_score"], "Objective_Final": opt["best_final_score"], "TrainSeconds": results[alg]["summary"]["TrainSeconds"]})

    pred_df = pd.DataFrame(pred_rows)
    metric_df = pd.DataFrame(metric_rows)

    if priority_mode == "AUC-first":
        metric_df = metric_df.sort_values(["SelectedMacroAUC", "Objective_Final", "SelectedMacroF1"], ascending=[False, False, False]).reset_index(drop=True)
    else:
        metric_df = metric_df.sort_values(["Objective_Final", "SelectedMacroAUC", "SelectedMacroF1"], ascending=[False, False, False]).reset_index(drop=True)
    best_alg = metric_df.iloc[0]["Algorithm"]
    metric_df["BestRecommendation"] = np.where(metric_df["Algorithm"] == best_alg, "BEST", "")
    pred_df = pred_df.merge(metric_df[["Algorithm", "BestRecommendation"]], on="Algorithm", how="left")

    st.subheader(f"Best Recommendation: {best_alg} ({priority_mode})")

    best_row = pred_df[pred_df["Algorithm"] == best_alg].iloc[0]
    recommended_output = ", ".join([f"{c}={best_row[c]:.2f}" for c in CONTROLLABLE_COLS])
    st.markdown("### Recommended Output Settings")
    st.markdown(f"- **Taste Profile selected** -> {', '.join(selected_tastes)}")
    st.markdown(f"- **Output** -> {recommended_output}")
    recommended_table = pd.DataFrame(
        [
            {
                "Taste Profile selected": ", ".join(selected_tastes),
                "Derived from Algorithm": best_alg,
                **{c: float(best_row[c]) for c in CONTROLLABLE_COLS},
            }
        ]
    )
    recommended_style = (
        recommended_table.style.format({c: "{:.2f}" for c in CONTROLLABLE_COLS})
        .set_caption("Recommended Output Settings (Best Algorithm)")
        .apply(
            lambda row: ["background-color: #dcfce7; font-weight: 700;" for _ in row],
            axis=1,
        )
        .set_table_styles(
            [
                {"selector": "caption", "props": "caption-side: top; font-size: 15px; font-weight: 700;"},
                {"selector": "th", "props": "background-color: #0f172a; color: white; text-align: center;"},
                {"selector": "td", "props": "text-align: center;"},
            ]
        )
    )
    render_scrollable_html_table(recommended_style.to_html(), max_height=220)

    st.markdown("### Predicted Outputs (HTML Table)")
    pred_style = pred_df.style.format({c: "{:.4f}" for c in pred_df.columns if c not in ["Algorithm", "BestRecommendation"]}).apply(
        lambda row: ["background-color: #dcfce7; font-weight: 700;" if row.get("BestRecommendation", "") == "BEST" else "" for _ in row], axis=1
    )
    render_scrollable_html_table(pred_style.to_html(), max_height=360)

    st.markdown("### Important Metrics for This Selection")
    metric_style = (
        metric_df.style.format(
            {
                "SelectedMacroAUC": "{:.4f}",
                "SelectedMacroAP": "{:.4f}",
                "SelectedMacroF1": "{:.4f}",
                "SelectedMeanBrier": "{:.4f}",
                "SelectedMeanECE": "{:.4f}",
                "Objective_Base": "{:.4f}",
                "Objective_Final": "{:.4f}",
                "TrainSeconds": "{:.2f}",
            }
        )
        .background_gradient(cmap="Greens", subset=["SelectedMacroAUC", "SelectedMacroAP", "SelectedMacroF1", "Objective_Final"])
        .background_gradient(cmap="Reds_r", subset=["SelectedMeanBrier", "SelectedMeanECE", "TrainSeconds"])
        .apply(lambda row: ["background-color: #dcfce7; font-weight: 700;" if row.get("BestRecommendation", "") == "BEST" else "" for _ in row], axis=1)
    )
    render_scrollable_html_table(metric_style.to_html(), max_height=340)

    if tuning_rows:
        st.markdown("### Tuning Summary")
        st.dataframe(pd.DataFrame(tuning_rows), use_container_width=True)

    st.markdown("### Selected Taste Probabilities by Algorithm")
    pcols = [f"P({t})" for t in selected_tastes]
    plot_df = pred_df[["Algorithm"] + pcols].set_index("Algorithm")
    fig, ax = plt.subplots(figsize=(10, 4))
    plot_df.plot(kind="bar", ax=ax)
    ax.set_ylabel("Probability")
    ax.set_xlabel("Algorithm")
    ax.tick_params(axis="x", rotation=30)
    fig.tight_layout()
    st.pyplot(fig)

    st.markdown("### Final Recommendation")
    st.info(
        f"Recommended model: {best_alg} | "
        f"SelectedMacroAUC={metric_df.iloc[0]['SelectedMacroAUC']:.4f}, "
        f"SelectedMacroF1={metric_df.iloc[0]['SelectedMacroF1']:.4f}, "
        f"Objective_Final={metric_df.iloc[0]['Objective_Final']:.4f}"
    )

    if run_shap:
        st.markdown("### SHAP Comparison")
        x2_train = train_df[CONTROLLABLE_COLS + PROCESS_COLS]
        shap_tastes = selected_tastes[:shap_max_tastes]
        rows = []
        with st.spinner("Computing SHAP values..."):
            for alg in algorithms:
                for t in shap_tastes:
                    vals = mean_abs_shap_for_model(results[alg]["stage2"][t], alg, x2_train, x2_train, bg_size=40, ex_size=60)
                    for f, v in zip(x2_train.columns, vals):
                        rows.append({"Algorithm": alg, "Taste": t, "Feature": f, "MeanAbsSHAP": float(v)})
        shap_long = pd.DataFrame(rows)

        agg = shap_long.groupby(["Algorithm", "Feature"], as_index=False)["MeanAbsSHAP"].mean()
        for alg in algorithms:
            sub = agg[agg["Algorithm"] == alg].sort_values("MeanAbsSHAP", ascending=False).head(10).sort_values("MeanAbsSHAP")
            fig, ax = plt.subplots(figsize=(8, 4))
            ax.barh(sub["Feature"], sub["MeanAbsSHAP"], color="#1f77b4")
            ax.set_title(f"{alg}: Top SHAP Features")
            ax.set_xlabel("Mean |SHAP|")
            fig.tight_layout()
            st.pyplot(fig)

        heat = (
            shap_long.groupby(["Feature", "Algorithm"], as_index=False)["MeanAbsSHAP"]
            .mean()
            .pivot(index="Feature", columns="Algorithm", values="MeanAbsSHAP")
        )
        top = heat.mean(axis=1).sort_values(ascending=False).head(12).index
        fig, ax = plt.subplots(figsize=(10, 6))
        sns.heatmap(heat.loc[top], cmap="YlOrRd", annot=True, fmt=".3f", ax=ax)
        ax.set_title("SHAP Mean |Contribution| by Algorithm")
        fig.tight_layout()
        st.pyplot(fig)


if __name__ == "__main__":
    main()
